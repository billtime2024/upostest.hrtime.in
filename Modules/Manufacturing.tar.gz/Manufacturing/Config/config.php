<?php

return [
    'name' => 'Manufacturing',
    'module_version' => '4.0',
    'pid' => 4,
];
