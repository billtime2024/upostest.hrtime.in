<tr>
	<td>
		{{$ingredient['full_name']}}
		<br>
		<small class="text-muted p-1">
			@if($ingredient['enable_stock'])
				@php
					$qty_available = !empty($ingredient['variation']->variation_location_details[0]) ? $ingredient['variation']->variation_location_details[0]->qty_available : 0;
				@endphp
				<span style="color: #00B050">{{ @num_format($qty_available) }} {{$ingredient['unit']}} @lang('lang_v1.in_stock')</span>
			@else
				--
			@endif
		</small>
		@if(!empty($ingredient['lot_numbers']) && collect($ingredient['lot_numbers'])->where('qty_available', '>', 0)->count() > 0)
		<br>
		<select name="ingredients[{{$ingredient['id']}}][lot_no_line_id]" class="form-control select2 lot_number input-sm" style="color: #000 !important;" required>
			<option value="">@lang('lang_v1.lot_n_expiry')</option>
			@foreach($ingredient['lot_numbers'] as $lot_number)
				@if($lot_number->qty_available > 0)
				@php
					$expiry_text = '';
					if(session('business.enable_product_expiry') == 1 && !empty($lot_number->exp_date)){
						if( \Carbon::now()->gt(\Carbon::createFromFormat('Y-m-d', $lot_number->exp_date)) ){
							$expiry_text = '(' . __('report.expired') . ')';
						}
					}
				@endphp
				<option value="{{$lot_number->purchase_line_id}}" data-qty_available="{{$lot_number->qty_available}}" data-purchase_price_inc_tax="{{isset($lot_number->purchase_price_inc_tax) ? $lot_number->purchase_price_inc_tax : 0}}" data-msg-max="@lang('lang_v1.quantity_error_msg_in_lot', ['qty'=> $lot_number->qty_formated, 'unit' => $ingredient['unit'] ])">
					@if(!empty($lot_number->lot_number) && session('business.enable_lot_number') == 1){{$lot_number->lot_number}} @endif
					@if(session('business.enable_lot_number') == 1 && session('business.enable_product_expiry') == 1) - @endif
					@if(session('business.enable_product_expiry') == 1 && !empty($lot_number->exp_date)) @lang('product.exp_date'): {{@format_date($lot_number->exp_date)}} @endif
					{{$expiry_text}}
				</option>
				@endif
			@endforeach
		</select>
		@endif
		<input type="hidden" class="ingredient_price" value="{{$ingredient['dpp_inc_tax']}}">
		<input type="hidden" name="ingredients[{{$ingredient['id']}}][variation_id]"  class="ingredient_id" value="{{$ingredient['variation_id']}}">
		<input type="hidden" class="unit_quantity" value="{{$ingredient['unit_quantity']}}">
		<input type="hidden" name="ingredients[{{$ingredient['id']}}][mfg_ingredient_group_id]" value="{{$ingredient['mfg_ingredient_group_id']}}">
	</td>
	<td>
		@php
			$variation = $ingredient['variation'];
			$multiplier = $ingredient['multiplier'];
			$allow_decimal = $ingredient['allow_decimal'];
			$qty_available = 0;
			if($ingredient['enable_stock'] == 1) {
				$max_qty_rule = !empty($variation->variation_location_details[0]->qty_available) ? $variation->variation_location_details[0]->qty_available : 0;
				$qty_available = $max_qty_rule;
				$max_qty_rule = $max_qty_rule / $multiplier;
				$max_qty_msg = __('validation.custom-messages.quantity_not_available', ['qty'=> number_format($max_qty_rule, 2), 'unit' => $ingredient['unit']  ]);
			}
			
		@endphp
		<div class="@if(!empty($ingredient['sub_units'])) input_inline @else input-group @endif">
			<input 
			type="text" 
			data-min="1" 
			class="form-control input-sm input_number mousetrap total_quantities" 
			value="{{@format_quantity($ingredient['quantity'])}}" 
			name="ingredients[{{$ingredient['id']}}][quantity]" 
			data-allow-overselling="@if(empty($pos_settings['allow_overselling'])){{'false'}}@else{{'true'}}@endif"
			@if($allow_decimal) 
				data-decimal=1 
			@else 
				data-decimal=0 
				data-rule-abs_digit="true" 
				data-msg-abs_digit="@lang('lang_v1.decimal_value_not_allowed')" 
			@endif 
				data-rule-required="true" 
				data-msg-required="@lang('validation.custom-messages.this_field_is_required')" 
			@if($ingredient['enable_stock'] == 1 && empty($pos_settings['allow_overselling']) ) 	
				data-rule-max-value="{{$max_qty_rule}}"  
				data-msg-max-value="{{$max_qty_msg}}" 
				data-qty_available={{$qty_available}}
			@endif 

			@if(!empty($manufacturing_settings['disable_editing_ingredient_qty']))
			readonly
			@endif
			>
			<span class="@if(empty($ingredient['sub_units'])) input-group-addon @endif line_unit_span">
			@if(empty($ingredient['sub_units'])) 
				{{$ingredient['unit']}}
			@else
				<select name="ingredients[{{$ingredient['id']}}][sub_unit_id]" class="input-sm form-control sub_unit" 
				@if(!empty($manufacturing_settings['disable_editing_ingredient_qty']))
				disabled="" 
				@endif
			>
					@foreach($ingredient['sub_units'] as $key => $value)
						<option 
							value="{{$key}}" 
							data-allow_decimal="{{$value['allow_decimal']}}"
							data-multiplier="{{$value['multiplier']}}"
							data-unit_name="{{$value['name']}}"
							@if($ingredient['sub_unit_id'] == $key) selected @endif>{{$value['name']}}</option>
					@endforeach
				</select>

				@if(!empty($manufacturing_settings['disable_editing_ingredient_qty']))
					<input type="hidden" name="ingredients[{{$ingredient['id']}}][sub_unit_id]" value="{{$ingredient['sub_unit_id']}}">
				@endif
			@endif
			</span>
		</div>
	</td>
	<td>
		<div class="input-group">
			<input type="text" name="ingredients[{{$ingredient['id']}}][mfg_waste_percent]" value="{{@format_quantity($ingredient['waste_percent'])}}" class="form-control input-sm input_number mfg_waste_percent">
			<span class="input-group-addon"><i class="fa fa-percent"></i></span>
		</div>
	</td>
	<td>
		<span class="row_final_quantity">{{@format_quantity($ingredient['final_quantity'])}}</span> <span class="row_unit_text">{{$ingredient['unit']}}</span>
	</td>
	<td>
		<span class="ingredient_total_price display_currency" data-currency_symbol="true">{{@num_format($ingredient['total_price'])}}</span>
		<input type="hidden" class="total_price" value="{{$ingredient['total_price']}}">
	</td>
</tr>

<script>
$(document).ready(function() {
    // Initialize lot prices on page load
    $('.lot_number').each(function() {
        var $select = $(this);
        var $row = $select.closest('tr');
        var selectedOption = $select.find('option:selected');

        if (selectedOption.val() && selectedOption.data('purchase_price_inc_tax')) {
            var purchasePriceIncTax = parseFloat(selectedOption.data('purchase_price_inc_tax')) || 0;
            $row.find('.ingredient_price').val(purchasePriceIncTax);

            // Recalculate total price with the lot price
            var quantity = parseFloat($row.find('.total_quantities').val()) || 0;
            var totalPrice = quantity * purchasePriceIncTax;
            $row.find('.ingredient_total_price').text(__number_f(totalPrice, false, false, __currency_precision));
            $row.find('.total_price').val(totalPrice);
        }
    });

    // Update total on page load
    updateTotalIngredientPrice();

    // Handle lot number change for ingredients
    $(document).on('change', '.lot_number', function() {
	       var $select = $(this);
	       var $row = $select.closest('tr');
	       var selectedOption = $select.find('option:selected');

	       // Get the purchase price from the selected lot
	       var purchasePriceIncTax = parseFloat(selectedOption.data('purchase_price_inc_tax')) || 0;

	       // Update the hidden ingredient price input
	       $row.find('.ingredient_price').val(purchasePriceIncTax);

	       // Get the quantity
	       var quantity = parseFloat($row.find('.total_quantities').val()) || 0;

	       // Calculate new total price
	       var totalPrice = quantity * purchasePriceIncTax;

	       // Update the display and hidden total price
	       $row.find('.ingredient_total_price').text(__number_f(totalPrice, false, false, __currency_precision));
	       $row.find('.total_price').val(totalPrice);

	       // Update overall total if needed
	       updateTotalIngredientPrice();
	   });

	   // Handle quantity change for ingredients
	   $(document).on('change keyup', '.total_quantities', function() {
	       var $input = $(this);
	       var $row = $input.closest('tr');

	       // Get the current ingredient price (from lot or default)
	       var ingredientPrice = parseFloat($row.find('.ingredient_price').val()) || 0;

	       // Get the quantity
	       var quantity = parseFloat($input.val()) || 0;

	       // Calculate new total price
	       var totalPrice = quantity * ingredientPrice;

	       // Update the display and hidden total price
	       $row.find('.ingredient_total_price').text(__number_f(totalPrice, false, false, __currency_precision));
	       $row.find('.total_price').val(totalPrice);

	       // Update overall total
	       updateTotalIngredientPrice();
	   });

	   // Function to update total ingredient price
	   function updateTotalIngredientPrice() {
	       var total = 0;
	       $('.total_price').each(function() {
	           total += parseFloat($(this).val()) || 0;
	       });
	       $('#total_ingredient_price').text(__number_f(total, true, false, __currency_precision));
	   }
});
</script>