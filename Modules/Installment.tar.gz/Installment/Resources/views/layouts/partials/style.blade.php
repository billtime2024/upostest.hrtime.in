<style>
    .table-striped th{
        background-color: #626161 !important;
        color: #ffffff;
    }


</style>