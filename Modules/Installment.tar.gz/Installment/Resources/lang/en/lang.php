<?php
return [
   
'installment_customer'=>'All Installments',
'customers'=>'Customers',
'installment'=>'Installment',
'sell_installment'=>'Invoice installment',
'installment_status'=>'Installment Status',
'installment_report'=>'Installment Reports',
'supplier'=>'Supplier Installments',
'customer'=>'Customer Installments',
'customer_sells'=>'Sale invoices',
'installment_plan'=>'Installment Plans',
'installment_report'=>'Installment Reports',
'customer_instalment'=>'Customer Installments',
'day'=>'day(s)',
'month'=>'month(s)',
'year'=>'year(s)',
'datefrom'=>'Date Range from',
'dateto'=>'Date Range to',
'complex'=>'Compound Interest',
'simple'=>'Simple Interest',
'deleted_success'=>'Deleted successfully',
'system_added_success'=>'Installment Added successfully',
'system_updated_success'=>'Edited successfully',
'added_success'=>'Added successfully',
'submen3'=>'submen 3',

/*user_permissions*/
'view'=>'Installment Show',
'create'=>'Add installment',
'edit'=>'Editing Installment',
'delete'=>'delete installment',
'add_Collection'=>'installment collection',
'delete_Collection'=>'delete collection',
'system_add'=>'Add System',
'system_edit'=>'Edit System',
'system_delete'=>'Delete System',

/*End of user_permissions*/

'pebt_Collection'=>'Collection',
'all_installment'=>'All',
'paid_installment'=>'paid',
'due_installment'=>'due',
'late_installment'=>'late',
'de1_Collection'=>'delete collection',

];
