<?php
return [

'partners'=>'الشركاء',
'Partners'=>'الشركاء',
'pateners_assets'=>'الأصول والشركاء',
'something_went_wrong'=>' ! عفوا لقد حدث شئ خطأ',
 'Payment_deleted'=>'تم حذف العملية بنجاح',
'saved_succes'=>'تم الحفظ بنجاح',
'partner_module'=>'وحدة الشركاء',
'partner_view'=>'عرض الشركاء',
'partner_create'=>'إضافة شريك',
'partner_edit'=>'تعديل بيانات',
'partner_delete'=>'حذف شريك',
'payment_view'=>'عرض مدفوعات شريك',
'payment_edit'=>'تعديل مدفوعات شريك',
'payment_delete'=>'حذف مدفوعات شريك',


'quantity'=>'الكمية'
];
