@extends('layouts.app')
@section('title',' الشركاء')

@section('content')
    @include('partners::layouts.nav')
@endsection