@extends('layouts.app')
@section('title','إضافة الشركاء')

@section('content')
    @include('partners::layouts.nav')

@endsection