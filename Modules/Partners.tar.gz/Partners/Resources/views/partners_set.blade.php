@extends('layouts.app')
@section('title','الموقف المالي')

@section('content')
    @include('partners::layouts.nav')
@endsection