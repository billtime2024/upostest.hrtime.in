@extends('layouts.app')
@section('title','سجل مدفوعات الشركاء')

@section('content')
    @include('partners::layouts.nav')
@endsection