<?php

namespace Modules\Academy\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class AcademyCourse extends Model
{
    use HasFactory, SoftDeletes;

    protected $guarded = ['id'];

    protected $casts = [
        'default_fee' => 'decimal:2',
        'is_fixed_session' => 'boolean',
    ];

    public function getNameAttribute()
    {
        return $this->title;
    }

    public function getDescriptionAttribute()
    {
        return $this->short_description;
    }

    public function created_by_user()
    {
        return $this->belongsTo(\App\User::class, 'created_by');
    }

    public function business()
    {
        return $this->belongsTo(\App\Business::class, 'business_id');
    }

    public function classes()
    {
        return $this->hasMany(\Modules\Academy\Entities\AcademyClass::class, 'course_id');
    }
}