<?php

namespace Modules\Academy\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AcademyEnrollment extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    protected $casts = [
        'enrollment_date' => 'date',
        'fee' => 'decimal:2',
        'enrollment_fee' => 'decimal:2',
        'course_fee' => 'decimal:2',
        'discount' => 'decimal:2',
    ];

    public function class()
    {
        return $this->belongsTo(\Modules\Academy\Entities\AcademyClass::class, 'class_id');
    }

    public function student()
    {
        return $this->belongsTo(\Modules\Academy\Entities\AcademyStudent::class, 'student_id');
    }

    public function transaction()
    {
        return $this->belongsTo(\App\Transaction::class, 'transaction_id');
    }

    public function created_by_user()
    {
        return $this->belongsTo(\App\User::class, 'created_by');
    }

    public function business()
    {
        return $this->belongsTo(\App\Business::class, 'business_id');
    }

    public function attendances()
    {
        return $this->hasMany(\Modules\Academy\Entities\AcademyAttendance::class, 'enrollment_id');
    }
}