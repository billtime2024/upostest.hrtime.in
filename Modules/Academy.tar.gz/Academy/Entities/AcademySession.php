<?php

namespace Modules\Academy\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AcademySession extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    protected $casts = [
        'session_date' => 'date',
        'start_time' => 'datetime:H:i',
        'end_time' => 'datetime:H:i',
    ];

    public function class()
    {
        return $this->belongsTo(\Modules\Academy\Entities\AcademyClass::class, 'class_id');
    }

    public function room()
    {
        return $this->belongsTo(\App\BusinessLocation::class, 'room_id');
    }

    public function created_by_user()
    {
        return $this->belongsTo(\App\User::class, 'created_by');
    }

    public function business()
    {
        return $this->belongsTo(\App\Business::class, 'business_id');
    }

    public function attendances()
    {
        return $this->hasMany(\Modules\Academy\Entities\AcademyAttendance::class, 'session_id');
    }
}