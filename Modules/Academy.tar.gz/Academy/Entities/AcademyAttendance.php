<?php

namespace Modules\Academy\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AcademyAttendance extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    protected $casts = [
        'present' => 'boolean',
        'check_in_time' => 'datetime',
    ];

    public function session()
    {
        return $this->belongsTo(\Modules\Academy\Entities\AcademySession::class, 'session_id');
    }

    public function enrollment()
    {
        return $this->belongsTo(\Modules\Academy\Entities\AcademyEnrollment::class, 'enrollment_id');
    }

    public function created_by_user()
    {
        return $this->belongsTo(\App\User::class, 'created_by');
    }

    public function business()
    {
        return $this->belongsTo(\App\Business::class, 'business_id');
    }
}