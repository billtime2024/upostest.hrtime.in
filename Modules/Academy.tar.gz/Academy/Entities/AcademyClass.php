<?php

namespace Modules\Academy\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class AcademyClass extends Model
{
    use HasFactory, SoftDeletes;

    protected $guarded = ['id'];

    protected $casts = [
        'schedule' => 'array',
        'start_date' => 'date',
        'end_date' => 'date',
        'auto_generate_sessions' => 'boolean',
        'default_session_start_time' => 'datetime:H:i',
        'default_session_end_time' => 'datetime:H:i',
    ];

    public function course()
    {
        return $this->belongsTo(\Modules\Academy\Entities\AcademyCourse::class, 'course_id');
    }

    public function instructor()
    {
        return $this->belongsTo(\App\User::class, 'instructor_id');
    }

    public function location()
    {
        return $this->belongsTo(\App\BusinessLocation::class, 'location_id');
    }

    public function created_by_user()
    {
        return $this->belongsTo(\App\User::class, 'created_by');
    }

    public function business()
    {
        return $this->belongsTo(\App\Business::class, 'business_id');
    }

    public function sessions()
    {
        return $this->hasMany(\Modules\Academy\Entities\AcademySession::class, 'class_id');
    }

    public function enrollments()
    {
        return $this->hasMany(\Modules\Academy\Entities\AcademyEnrollment::class, 'class_id');
    }
}