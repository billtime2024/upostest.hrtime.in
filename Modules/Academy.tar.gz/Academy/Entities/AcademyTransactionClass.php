<?php
namespace Modules\Academy\Entities;

use App\Transaction;


class AcademyTransactionClass extends Transaction
{
    public function enrollments()
    {
        return $this->hasMany(\Modules\Academy\Entities\AcademyEnrollment::class, 'transaction_id', 'id');
    }
}