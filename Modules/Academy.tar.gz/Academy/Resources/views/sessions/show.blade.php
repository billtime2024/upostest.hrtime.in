@extends('academy::layouts.master')
@section('title', __('academy::lang.sessions'))
@section('content')
<section class="content-header">
    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
        @lang('academy::lang.sessions')
    </h1>
</section>

<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('title')
            @lang('messages.view')
        @endslot

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.name'):</strong>
                    <p>{{ $session->name ?: __('academy::lang.na') }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.class'):</strong>
                    <p>{{ $session->class ? $session->class->name : __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.start_date'):</strong>
                    <p>{{ $session->start_date ? $session->start_date->format('Y-m-d') : __('academy::lang.na') }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.end_date'):</strong>
                    <p>{{ $session->end_date ? $session->end_date->format('Y-m-d') : __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.start_time'):</strong>
                    <p>{{ $session->start_time ?: __('academy::lang.na') }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.end_time'):</strong>
                    <p>{{ $session->end_time ?: __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <h4>@lang('academy::lang.bulk_attendance')</h4>
                <button class="tw-dw-btn tw-dw-btn-success bulk-mark-present" data-session-id="{{ $session->id }}" data-present="1">
                    @lang('academy::lang.mark_all_present')
                </button>
                <button class="tw-dw-btn tw-dw-btn-error bulk-mark-absent" data-session-id="{{ $session->id }}" data-present="0">
                    @lang('academy::lang.mark_all_absent')
                </button>
            </div>
        </div>

        @if($session->attendances && $session->attendances->count() > 0)
        <div class="row">
            <div class="col-md-12">
                <h4>@lang('academy::lang.attendances')</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>@lang('academy::lang.student')</th>
                            <th>@lang('academy::lang.present')</th>
                            <th>@lang('academy::lang.check_in_time')</th>
                            <th>@lang('academy::lang.remarks')</th>
                            <th>@lang('lang_v1.created_at')</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($session->attendances as $attendance)
                        <tr>
                            <td>{{ $attendance->enrollment && $attendance->enrollment->contact ? $attendance->enrollment->contact->name : __('academy::lang.na') }}</td>
                            <td>{{ $attendance->present ? __('academy::lang.present') : __('academy::lang.absent') }}</td>
                            <td>{{ $attendance->check_in_time ? $attendance->check_in_time->format('Y-m-d H:i:s') : __('academy::lang.na') }}</td>
                            <td>{{ $attendance->remarks ?: __('academy::lang.na') }}</td>
                            <td>{{ $attendance->created_at ? $attendance->created_at->format('Y-m-d H:i:s') : __('academy::lang.na') }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        @endif

        <div class="row">
            <div class="col-md-12">
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademySessionController::class, 'edit'], ['session' => $session->id]) }}" class="tw-dw-btn tw-dw-btn-primary">
                    @lang('messages.edit')
                </a>
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademySessionController::class, 'index']) }}" class="tw-dw-btn tw-dw-btn-outline tw-dw-btn-secondary">
                    @lang('messages.back')
                </a>
            </div>
        </div>
    @endcomponent
</section>
@endsection

@section('javascript')
<script>
$(document).ready(function() {
    $('.bulk-mark-present, .bulk-mark-absent').on('click', function() {
        var sessionId = $(this).data('session-id');
        var present = $(this).data('present');

        if (confirm('Are you sure you want to mark all students as ' + (present ? 'present' : 'absent') + ' for this session?')) {
            $.ajax({
                url: '{{ route("academy.attendances.bulk_mark") }}',
                method: 'POST',
                data: {
                    session_id: sessionId,
                    present: present,
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.msg);
                        location.reload();
                    } else {
                        toastr.error(response.msg);
                    }
                },
                error: function() {
                    toastr.error('{{ __("messages.something_went_wrong") }}');
                }
            });
        }
    });
});
</script>
@endsection