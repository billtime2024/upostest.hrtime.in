@extends('academy::layouts.master')
@section('title', __('academy::lang.reports'))
@section('content')
    <section class="content-header">
        <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black"> @lang('academy::lang.reports')
        </h1>
    </section>

    <!-- Main content -->
    <section class="content">
        @component('components.widget')
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        {!! Form::open(['url' => action([\Modules\Academy\Http\Controllers\AcademyReportController::class, 'index']), 'method' => 'get', 'id' => 'report_form']) !!}
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    {!! Form::label('date_from', __('Date From') . ':') !!}
                                    {!! Form::text('date_from', request()->get('date_from'), ['class' => 'form-control', 'id' => 'date_from', 'readonly']) !!}
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    {!! Form::label('date_to', __('Date To') . ':') !!}
                                    {!! Form::text('date_to', request()->get('date_to'), ['class' => 'form-control', 'id' => 'date_to', 'readonly']) !!}
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <br>
                                    <button type="submit" class="btn btn-primary">@lang('messages.filter')</button>
                                </div>
                            </div>
                        </div>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>

            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#enrollment_report" data-toggle="tab">@lang('academy::lang.enrollments')</a></li>
                    <li><a href="#attendance_report" data-toggle="tab">@lang('academy::lang.attendance')</a></li>
                    <li><a href="#revenue_report" data-toggle="tab">@lang('academy::lang.revenue')</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="enrollment_report">
                        <table class="table table-bordered table-striped" id="enrollment_report_table">
                            <thead>
                                <tr>
                                    <th>@lang('Sales Ref No')</th>
                                    <th>@lang('lang_v1.date')</th>
                                    <th>@lang('sale.total_amount')</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div class="tab-pane" id="attendance_report">
                        <table class="table table-bordered table-striped" id="attendance_report_table">
                            <thead>
                                <tr>
                                    <th>@lang('sale.ref_no')</th>
                                    <th>@lang('lang_v1.date')</th>
                                    <th>@lang('sale.total_amount')</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div class="tab-pane" id="revenue_report">
                        <table class="table table-bordered table-striped" id="revenue_report_table">
                            <thead>
                                <tr>
                                    <th>@lang('sale.ref_no')</th>
                                    <th>@lang('lang_v1.date')</th>
                                    <th>@lang('sale.total_amount')</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        @endcomponent
    </section>
@endsection

@section('javascript')
    <script type="text/javascript">
        $(document).ready(function() {
            $('#date_from, #date_to').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd'
            });

            var date_from = '{{ request()->get("date_from") }}';
            var date_to = '{{ request()->get("date_to") }}';

            enrollment_report_table = $('#enrollment_report_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ action([\Modules\Academy\Http\Controllers\AcademyReportController::class, 'enrollment_report']) }}",
                    data: function(d) {
                        d.date_from = date_from;
                        d.date_to = date_to;
                    }
                },
                columns: [
                    { data: 'ref_no', name: 'ref_no' },
                    { data: 'transaction_date', name: 'transaction_date' },
                    { data: 'final_total', name: 'final_total' }
                ]
            });

            attendance_report_table = $('#attendance_report_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ action([\Modules\Academy\Http\Controllers\AcademyReportController::class, 'attendance_report']) }}",
                    data: function(d) {
                        d.date_from = date_from;
                        d.date_to = date_to;
                    }
                },
                columns: [
                    { data: 'ref_no', name: 'ref_no' },
                    { data: 'transaction_date', name: 'transaction_date' },
                    { data: 'final_total', name: 'final_total' }
                ]
            });

            revenue_report_table = $('#revenue_report_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ action([\Modules\Academy\Http\Controllers\AcademyReportController::class, 'revenue_report']) }}",
                    data: function(d) {
                        d.date_from = date_from;
                        d.date_to = date_to;
                    }
                },
                columns: [
                    { data: 'ref_no', name: 'ref_no' },
                    { data: 'transaction_date', name: 'transaction_date' },
                    { data: 'final_total', name: 'final_total' }
                ]
            });
        });
    </script>
@endsection