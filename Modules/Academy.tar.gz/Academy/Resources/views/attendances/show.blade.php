@extends('academy::layouts.master')
@section('title', __('academy::lang.attendances'))
@section('content')
<section class="content-header">
    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
        @lang('academy::lang.attendances')
    </h1>
</section>

<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('title')
            @lang('messages.view')
        @endslot

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.session'):</strong>
                    <p>{{ $attendance->session ? $attendance->session->name : __('academy::lang.na') }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.student'):</strong>
                    <p>{{ $attendance->enrollment && $attendance->enrollment->student && $attendance->enrollment->student->contact ? $attendance->enrollment->student->contact->name : __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.present'):</strong>
                    <p>{{ $attendance->present ? __('academy::lang.present') : __('academy::lang.absent') }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.check_in_time'):</strong>
                    <p>{{ $attendance->check_in_time ? $attendance->check_in_time->format('Y-m-d H:i:s') : __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.remarks'):</strong>
                    <p>{{ $attendance->remarks ?: __('academy::lang.na') }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('lang_v1.created_at'):</strong>
                    <p>{{ $attendance->created_at ? $attendance->created_at->format('Y-m-d H:i:s') : __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'edit'], ['attendance' => $attendance->id]) }}" class="tw-dw-btn tw-dw-btn-primary">
                    @lang('messages.edit')
                </a>
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'index']) }}" class="tw-dw-btn tw-dw-btn-outline tw-dw-btn-secondary">
                    @lang('messages.back')
                </a>
            </div>
        </div>
    @endcomponent
</section>
@endsection