@extends('academy::layouts.master')
@section('title', __('academy::lang.attendances'))
@section('content')
<section class="content-header">
    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
        @lang('academy::lang.attendances')
    </h1>
</section>

<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('title')
            @lang('messages.add')
        @endslot

        {!! Form::open(['url' => action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'store']), 'method' => 'post', 'id' => 'attendance_form']) !!}
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('session_id', __('academy::lang.session') . ':*') !!}
                    {!! Form::select('session_id', $sessions, null, ['class' => 'form-control select2', 'required', 'placeholder' => __('messages.please_select')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('enrollment_id', __('academy::lang.student') . ':*') !!}
                    {!! Form::select('enrollment_id', $enrollments, null, ['class' => 'form-control select2', 'required', 'placeholder' => __('messages.please_select')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::checkbox('present', 1, null, ['id' => 'present']) !!}
                    {!! Form::label('present', __('academy::lang.present')) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('check_in_time', __('academy::lang.check_in_time') . ':') !!}
                    {!! Form::text('check_in_time', null, ['class' => 'form-control datetimepicker', 'placeholder' => __('academy::lang.check_in_time')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    {!! Form::label('remarks', __('academy::lang.remarks') . ':') !!}
                    {!! Form::textarea('remarks', null, ['class' => 'form-control', 'rows' => 3, 'placeholder' => __('academy::lang.remarks')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <button type="submit" class="tw-dw-btn tw-dw-btn-primary">
                    @lang('messages.save')
                </button>
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'index']) }}" class="tw-dw-btn tw-dw-btn-outline tw-dw-btn-secondary">
                    @lang('messages.cancel')
                </a>
            </div>
        </div>
        {!! Form::close() !!}
    @endcomponent
</section>
@endsection

@section('javascript')
<script type="text/javascript">
    $(document).ready(function() {
        $('.select2').select2();

        $('.datetimepicker').datetimepicker({
            format: 'Y-m-d H:i:s',
            step: 15
        });
    });
</script>
@endsection