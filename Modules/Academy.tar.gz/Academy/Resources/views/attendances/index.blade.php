@extends('academy::layouts.master')
@section('title', __('academy::lang.attendances'))
@section('content')
    <section class="content-header">
        <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black"> @lang('academy::lang.attendances')
        </h1>
        <p><i class="fa fa-info-circle"></i> @lang('academy::lang.attendances_help_text', ['default' => 'Manage student attendance here.']) </p>
    </section>

    <!-- Main content -->
    <section class="content">
        @component('components.widget')
            <div class="box-tools tw-flex tw-justify-end tw-gap-2.5 tw-mb-4">
                @can('academy.manage_attendance')
                        <a class="tw-dw-btn tw-bg-gradient-to-r tw-from-indigo-600 tw-to-blue-500 tw-font-bold tw-text-white tw-border-none tw-rounded-full pull-right"
                            href="{{ action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'create']) }}">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                class="icon icon-tabler icons-tabler-outline icon-tabler-plus">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M12 5l0 14" />
                                <path d="M5 12l14 0" />
                            </svg> @lang('messages.add')
                        </a>
                @endcan
            </div>
            <table class="table table-bordered table-striped" id="attendances_table">
                <thead>
                    <tr>
                        <th>
                            @lang('academy::lang.session')
                        </th>
                        <th>
                            @lang('academy::lang.student')
                        </th>
                        <th>
                            @lang('academy::lang.present')
                        </th>
                        <th>
                            @lang('academy::lang.check_in_time')
                        </th>
                        <th>
                            @lang('academy::lang.remarks')
                        </th>
                        <th>
                            @lang('lang_v1.created_at')
                        </th>
                        <th>
                            @lang('messages.action')
                        </th>
                    </tr>
                </thead>
            </table>
        @endcomponent
    </section>
@endsection

@section('javascript')
    <script type="text/javascript">
        $(document).ready(function() {
            attendances_table = $('#attendances_table').DataTable({
                processing: true,
                serverSide: true,

                ajax: {
                    url: "{{ action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'index']) }}",
                },
                aaSorting: [
                    [5, 'desc']
                ],
                columns: [{
                        data: 'session.name',
                        name: 'session.name'
                    },
                    {
                        data: 'enrollment.student.contact.name',
                        name: 'enrollment.student.contact.name',
                    },
                    {
                        data: 'present',
                        name: 'present',
                        "searchable": false
                    },
                    {
                        data: 'check_in_time',
                        name: 'check_in_time',
                        "searchable": false
                    },
                    {
                        data: 'remarks',
                        name: 'academy_attendances.remarks'
                    },
                    {
                        data: 'created_at',
                        name: 'academy_attendances.created_at'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        sorting: false,
                    }
                ],
            });

        });
    </script>
@endsection