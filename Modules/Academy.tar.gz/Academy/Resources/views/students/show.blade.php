@extends('academy::layouts.master')
@section('title', __('academy::lang.students'))
@section('content')
<section class="content-header">
    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
        @lang('academy::lang.students')
    </h1>
</section>

<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('title')
            @lang('messages.view')
        @endslot

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('contact.customer'):</strong>
                    <p>{{ $student->contact ? $student->contact->name : __('academy::lang.na') }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.admission_no'):</strong>
                    <p>{{ $student->admission_no ?: __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.enrollment_date'):</strong>
                    <p>{{ $student->enrollment_date ? $student->enrollment_date->format('Y-m-d') : __('academy::lang.na') }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('lang_v1.created_at'):</strong>
                    <p>{{ $student->created_at ? $student->created_at->format('Y-m-d H:i:s') : __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        @if($student->enrollments && $student->enrollments->count() > 0)
        <div class="row">
            <div class="col-md-12">
                <h4>@lang('academy::lang.enrollments')</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>@lang('academy::lang.course')</th>
                            <th>@lang('academy::lang.class')</th>
                            <th>@lang('lang_v1.created_at')</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($student->enrollments as $enrollment)
                        <tr>
                            <td>{{ $enrollment->course ? $enrollment->course->name : __('academy::lang.na') }}</td>
                            <td>{{ $enrollment->class ? $enrollment->class->name : __('academy::lang.na') }}</td>
                            <td>{{ $enrollment->created_at ? $enrollment->created_at->format('Y-m-d') : __('academy::lang.na') }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        @endif

        <div class="row">
            <div class="col-md-12">
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'edit'], ['student' => $student->id]) }}" class="tw-dw-btn tw-dw-btn-primary">
                    @lang('messages.edit')
                </a>
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'index']) }}" class="tw-dw-btn tw-dw-btn-outline tw-dw-btn-secondary">
                    @lang('messages.back')
                </a>
            </div>
        </div>
    @endcomponent
</section>
@endsection