@extends('academy::layouts.master')
@section('title', __('academy::lang.students'))
@section('content')
    <section class="content-header">
        <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black"> @lang('academy::lang.students')
        </h1>
        <p><i class="fa fa-info-circle"></i> @lang('academy::lang.students_help_text') </p>
    </section>

    <!-- Main content -->
    <section class="content">

        @component('components.widget')
            <div class="box-tools tw-flex tw-justify-end tw-gap-2.5 tw-mb-4">
                @can('academy.add_student')
                        <a class="tw-dw-btn tw-bg-gradient-to-r tw-from-indigo-600 tw-to-blue-500 tw-font-bold tw-text-white tw-border-none tw-rounded-full pull-right"
                         href="{{ action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'create']) }}">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                class="icon icon-tabler icons-tabler-outline icon-tabler-plus">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M12 5l0 14" />
                                <path d="M5 12l14 0" />
                            </svg> @lang('messages.add')
                        </a>
                @endcan
            </div>
            <table class="table table-bordered table-striped" id="students_table">
                <thead>
                    <tr>
                        <th>
                            @lang('academy::lang.name')
                        </th>
                        <th>
                            @lang('academy::lang.email')
                        </th>
                        <th>
                            @lang('academy::lang.phone')
                        </th>
                        <th>
                            @lang('lang_v1.created_at')
                        </th>
                        <th>
                            @lang('messages.action')
                        </th>
                    </tr>
                </thead>
            </table>
        @endcomponent

    </section>
    <!-- /.content -->

@endsection

@section('javascript')

    <script type="text/javascript">
        $(document).ready(function() {
            students_table = $('#students_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'index']) }}",
                },
                aaSorting: [
                    [3, 'desc']
                ],
                columns: [{
                        data: 'contact_name',
                        name: 'contact_name'
                    },
                    {
                        data: 'email',
                        name: 'contact.email'
                    },
                    {
                        data: 'phone',
                        name: 'contact.mobile'
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        sorting: false,
                    },
                ]
            });

            $(document).on('click', 'a.delete_student_confirmation', function(e) {
                e.preventDefault();
                swal({
                    title: LANG.sure,
                    text: "{{ __('academy::lang.delete_student_confirmation') }}",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                }).then((confirmed) => {
                    if (confirmed) {
                        window.location.href = $(this).attr('href');
                    }
                });
            });
        });
    </script>

@endsection