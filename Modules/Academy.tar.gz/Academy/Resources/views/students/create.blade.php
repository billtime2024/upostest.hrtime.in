@extends('academy::layouts.master')
@section('title', __('academy::lang.students'))
@section('content')
<section class="content-header">
    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
        @lang('academy::lang.students')
    </h1>
</section>

<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('title')
            @lang('messages.add')
        @endslot

        {!! Form::open(['url' => action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'store']), 'method' => 'post', 'id' => 'student_form']) !!}
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('contact_id', __('contact.customer') . ':*') !!}
                    {!! Form::select('contact_id', $contacts->pluck('name', 'id'), null, ['class' => 'form-control select2', 'required', 'placeholder' => __('messages.please_select')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('admission_no', __('academy::lang.admission_no') . ':') !!}
                    {!! Form::text('admission_no', null, ['class' => 'form-control', 'placeholder' => __('academy::lang.admission_no')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('enrollment_date', __('academy::lang.enrollment_date') . ':*') !!}
                    {!! Form::text('enrollment_date', \Carbon\Carbon::now()->format('Y-m-d'), ['class' => 'form-control datepicker', 'required', 'placeholder' => __('academy::lang.enrollment_date')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <button type="submit" class="tw-dw-btn tw-dw-btn-primary">
                    @lang('messages.save')
                </button>
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'index']) }}" class="tw-dw-btn tw-dw-btn-outline tw-dw-btn-secondary">
                    @lang('messages.cancel')
                </a>
            </div>
        </div>
        {!! Form::close() !!}
    @endcomponent
</section>
@endsection

@section('javascript')
<script type="text/javascript">
    $(document).ready(function() {
        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true
        });

        $('.select2').select2();
    });
</script>
@endsection