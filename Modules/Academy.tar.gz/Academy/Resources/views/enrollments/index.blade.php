@extends('academy::layouts.master')
@section('title', __('academy::lang.enrollments'))
@section('content')
    <section class="content-header">
        <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black"> @lang('academy::lang.enrollments')
        </h1>
        <p><i class="fa fa-info-circle"></i> @lang('academy::lang.enrollments_help_text') </p>
    </section>

    <!-- Main content -->
    <section class="content">
        @component('components.filters', ['title' => __('report.filters')])
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('student_id', __('academy::lang.student') . ':') !!}
                    {!! Form::select('student_id', $students, null, [
                        'class' => 'form-control select2',
                        'style' => 'width:100%',
                        'placeholder' => __('lang_v1.all'),
                    ]) !!}
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('course_id', __('academy::lang.course') . ':') !!}
                    {!! Form::select('course_id', $courses, null, [
                        'class' => 'form-control select2',
                        'style' => 'width:100%',
                        'placeholder' => __('lang_v1.all'),
                    ]) !!}
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('filter_payment_status', __('academy::lang.payment_status') . ':') !!}
                    {!! Form::select(
                        'filter_payment_status',
                        [
                            'paid' => __('lang_v1.paid'),
                            'due' => __('lang_v1.due'),
                            'partial' => __('lang_v1.partial'),
                            'overdue' => __('lang_v1.overdue'),
                        ],
                        null,
                        ['class' => 'form-control select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all')],
                    ) !!}
                </div>
            </div>
        @endcomponent
        @component('components.widget')
            <div class="box-tools tw-flex tw-justify-end tw-gap-2.5 tw-mb-4">
                @can('academy.add_enrollment')
                        <a class="tw-dw-btn tw-bg-gradient-to-r tw-from-indigo-600 tw-to-blue-500 tw-font-bold tw-text-white tw-border-none tw-rounded-full pull-right"
                            href="{{ action([\Modules\Academy\Http\Controllers\AcademyEnrollmentController::class, 'create']) }}">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                class="icon icon-tabler icons-tabler-outline icon-tabler-plus">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M12 5l0 14" />
                                <path d="M5 12l14 0" />
                            </svg> @lang('messages.add')
                        </a>
                @endcan
            </div>
            <table class="table table-bordered table-striped" id="enrollments_table">
                <thead>
                    <tr>
                        <th>
                            @lang('academy::lang.enrollment_id')
                        </th>
                        <th>
                            @lang('academy::lang.student')
                        </th>
                        <th>
                            @lang('academy::lang.course')
                        </th>
                        <th>
                            @lang('academy::lang.payment_status')
                        </th>
                        <th>
                            @lang('academy::lang.total_amount')
                        </th>
                        <th>
                            @lang('academy::lang.total_paid')
                        </th>
                        <th>
                            @lang('academy::lang.due')
                        </th>
                        <th>
                            @lang('lang_v1.created_at')
                        </th>
                        <th>
                            @lang('messages.action')
                        </th>
                    </tr>
                </thead>
            </table>
        @endcomponent
    </section>
    <div class="modal fade payment_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
    </div>
    <div class="modal fade edit_payment_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
    </div>
@endsection

@section('javascript')
    <script src="{{ asset('js/payment.js?v=' . $asset_v) }}"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            enrollments_table = $('#enrollments_table').DataTable({
                processing: true,
                serverSide: true,

                ajax: {
                    url: "{{ action([\Modules\Academy\Http\Controllers\AcademyEnrollmentController::class, 'index']) }}",
                    "data": function(d) {
                        d.student_id = $('#student_id').val();
                        d.course_id = $('#course_id').val();
                        d.payment_status = $('#filter_payment_status').val();
                    },
                },
                aaSorting: [
                    [7, 'desc']
                ],
                columns: [{
                        data: 'id',
                        name: 'academy_enrollments.id'
                    },
                    {
                        data: 'student_name',
                        name: 'c.name',
                    },
                    {
                        data: 'course_name',
                        name: 'course.title',
                    },
                    {
                        data: 'payment_status',
                        name: 't.payment_status'
                    },
                    {
                        data: 'total_amount',
                        name: 't.final_total'
                    },
                    {
                        data: 'total_paid',
                        name: 'total_paid',
                        "searchable": false
                    },
                    {
                        data: 'total_due',
                        name: 'total_due'
                    },
                    {
                        data: 'created_at',
                        name: 'academy_enrollments.created_at'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        sorting: false,
                    }
                ],
            });

            $(document).on('change', '#student_id, #course_id, #filter_payment_status', function() {
                enrollments_table.ajax.reload();
            });

        });
    </script>
@endsection