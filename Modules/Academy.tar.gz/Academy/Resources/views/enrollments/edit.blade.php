@extends('academy::layouts.master')
@section('title', __('academy::lang.enrollments'))
@section('content')
<section class="content-header">
    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
        @lang('academy::lang.enrollments')
    </h1>
</section>

<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('title')
            @lang('messages.edit')
        @endslot

        {!! Form::open(['url' => action([\Modules\Academy\Http\Controllers\AcademyEnrollmentController::class, 'update'], ['enrollment' => $transaction->id]), 'method' => 'put', 'id' => 'enrollment_form']) !!}
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('student_id', __('academy::lang.student') . ':*') !!}
                    {!! Form::select('student_id', $students, old('student_id', $enrollment->student_id ?? null), ['class' => 'form-control select2', 'required', 'placeholder' => __('messages.please_select')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('course_id', __('academy::lang.course') . ':*') !!}
                    {!! Form::select('course_id', $courses, old('course_id', $selected_course), ['class' => 'form-control select2', 'required', 'placeholder' => __('messages.please_select'), 'id' => 'course_id']) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('class_id', __('academy::lang.class') . ':*') !!}
                    {!! Form::select('class_id', $classes, old('class_id', $enrollment->class_id ?? null), ['class' => 'form-control select2', 'required', 'placeholder' => __('messages.please_select'), 'id' => 'class_id']) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('enrollment_date', __('academy::lang.enrollment_date') . ':*') !!}
                    {!! Form::text('enrollment_date', old('enrollment_date', $enrollment->enrollment_date ?? \Carbon\Carbon::now()->format('Y-m-d')), ['class' => 'form-control datepicker', 'required', 'placeholder' => __('academy::lang.enrollment_date')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('status', __('sale.status') . ':*') !!}
                    {!! Form::select('status', $status, old('status', $transaction->status), ['class' => 'form-control', 'required']) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('enrollment_fee', __('academy::lang.enrollment_fee') . ':*') !!}
                    {!! Form::number('enrollment_fee', old('enrollment_fee', $enrollment->enrollment_fee ?? 0), ['class' => 'form-control', 'required', 'step' => '0.01', 'placeholder' => __('academy::lang.enrollment_fee')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('course_fee', __('academy::lang.course_fee') . ':*') !!}
                    {!! Form::number('course_fee', old('course_fee', $enrollment->course_fee ?? 0), ['class' => 'form-control', 'required', 'step' => '0.01', 'placeholder' => __('academy::lang.course_fee')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('discount', __('academy::lang.discount') . ':') !!}
                    {!! Form::number('discount', old('discount', $enrollment->discount ?? 0), ['class' => 'form-control', 'step' => '0.01', 'placeholder' => __('academy::lang.discount')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('total_enrollment_amount', __('sale.total_amount') . ':*') !!}
                    {!! Form::number('total_enrollment_amount', old('total_enrollment_amount', $transaction->final_total), ['class' => 'form-control', 'required', 'step' => '0.01', 'placeholder' => __('sale.total_amount'), 'readonly']) !!}
                </div>
            </div>
        </div>

        @include('sale.partials.payment_rows', ['payment_types' => $payment_types, 'payment_line' => $payment_lines, 'change_return' => $change_return, 'accounts' => $accounts])

        <div class="row">
            <div class="col-md-12">
                <button type="submit" class="tw-dw-btn tw-dw-btn-primary">
                    @lang('messages.save')
                </button>
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyEnrollmentController::class, 'index']) }}" class="tw-dw-btn tw-dw-btn-outline tw-dw-btn-secondary">
                    @lang('messages.cancel')
                </a>
            </div>
        </div>
        {!! Form::close() !!}
    @endcomponent
</section>
@endsection

@section('javascript')
<script type="text/javascript">
    $(document).ready(function() {
        $('.select2').select2();

        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true
        });

        // Load classes when course is selected
        function loadClasses(course_id) {
            if (course_id) {
                $.ajax({
                    url: '{{ route("academy.enrollments.get_classes", ":course_id") }}'.replace(':course_id', course_id),
                    type: 'GET',
                    success: function(data) {
                        $('#class_id').empty().append('<option value="">' + '{{ __("messages.please_select") }}' + '</option>');
                        $.each(data, function(key, value) {
                            $('#class_id').append('<option value="' + key + '">' + value + '</option>');
                        });
                    }
                });
            } else {
                $('#class_id').empty().append('<option value="">' + '{{ __("messages.please_select") }}' + '</option>');
            }
        }

        // Load default fee when course is selected
        function loadCourseFee(course_id) {
            if (course_id) {
                // For now, we'll set a default fee. In a real implementation, you'd fetch from the course
                // Since we don't have AJAX for course details yet, we'll handle this in the backend
            }
        }

        $('#course_id').on('change', function() {
            var course_id = $(this).val();
            loadClasses(course_id);
            loadCourseFee(course_id);
        });

        // Load initial classes if course is selected
        $(document).ready(function() {
            var initial_course_id = $('#course_id').val();
            if (initial_course_id) {
                loadClasses(initial_course_id);
            }
        });

        // Calculate total amount
        function calculateTotal() {
            var enrollmentFee = parseFloat($('#enrollment_fee').val()) || 0;
            var courseFee = parseFloat($('#course_fee').val()) || 0;
            var discount = parseFloat($('#discount').val()) || 0;
            var total = enrollmentFee + courseFee - discount;
            $('#total_enrollment_amount').val(total.toFixed(2));
        }

        $('#enrollment_fee, #course_fee, #discount').on('input', calculateTotal);

        // Initialize payment rows
        initializePaymentRows();
    });
</script>
@endsection