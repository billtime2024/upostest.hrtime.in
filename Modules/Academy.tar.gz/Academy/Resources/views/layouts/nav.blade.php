<section class="no-print">
    <nav class="navbar-default tw-transition-all tw-duration-5000 tw-shrink-0 tw-rounded-2xl tw-m-[16px] tw-border-2 !tw-bg-white">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <a class="navbar-brand" href="{{ action([Modules\Academy\Http\Controllers\AcademyController::class, 'index']) }}"><i class="fas fa-graduation-cap"></i>@lang('academy::lang.academy')</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="navbar-collapse" id="academy-navbar-collapse">
                <ul class="nav navbar-nav">
                    <li @if(request()->segment(3) == 'dashboard') class="active" @endif><a href="{{ action([Modules\Academy\Http\Controllers\AcademyController::class, 'index']) }}">@lang('academy::lang.dashboard')</a></li>
                    <li @if(request()->segment(3) == 'students') class="active" @endif><a href="{{ action([Modules\Academy\Http\Controllers\AcademyStudentController::class, 'index']) }}">@lang('academy::lang.students')</a></li>
                    <li @if(request()->segment(3) == 'courses') class="active" @endif><a href="{{ action([Modules\Academy\Http\Controllers\AcademyCourseController::class, 'index']) }}">@lang('academy::lang.courses')</a></li>
                    <li @if(request()->segment(3) == 'classes') class="active" @endif><a href="{{ action([Modules\Academy\Http\Controllers\AcademyClassController::class, 'index']) }}">@lang('academy::lang.classes')</a></li>
                    <li @if(request()->segment(3) == 'enrollments') class="active" @endif><a href="{{ action([Modules\Academy\Http\Controllers\AcademyEnrollmentController::class, 'index']) }}">@lang('academy::lang.enrollments')</a></li>
                    <li @if(request()->segment(3) == 'attendances') class="active" @endif><a href="{{ action([Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'index']) }}">@lang('academy::lang.attendances')</a></li>
                    <li @if(request()->segment(3) == 'calendar') class="active" @endif><a href="{{ action([Modules\Academy\Http\Controllers\AcademyController::class, 'calendar']) }}">@lang('academy::lang.calendar')</a></li>
                    <li @if(request()->segment(3) == 'reports') class="active" @endif><a href="{{ action([Modules\Academy\Http\Controllers\AcademyReportController::class, 'index']) }}">@lang('academy::lang.reports')</a></li>
                    <li @if(request()->segment(3) == 'settings') class="active" @endif><a href="{{ action([Modules\Academy\Http\Controllers\AcademySettingController::class, 'index']) }}">@lang('messages.settings')</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
</section>