@extends('academy::layouts.master')
@section('title', __('academy::lang.courses'))
@section('content')
<section class="content-header">
    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
        @lang('academy::lang.courses')
    </h1>
</section>

<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('title')
            @lang('messages.add')
        @endslot

        {!! Form::open(['url' => action([\Modules\Academy\Http\Controllers\AcademyCourseController::class, 'store']), 'method' => 'post', 'id' => 'course_form']) !!}
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('title', __('academy::lang.name') . ':*') !!}
                    {!! Form::text('title', null, ['class' => 'form-control', 'required', 'placeholder' => __('academy::lang.name')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('code', __('academy::lang.code') . ':') !!}
                    {!! Form::text('code', null, ['class' => 'form-control', 'placeholder' => __('academy::lang.code')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('default_fee', __('academy::lang.price') . ':*') !!}
                    {!! Form::number('default_fee', 0, ['class' => 'form-control', 'required', 'step' => '0.01', 'placeholder' => __('academy::lang.price')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('duration', __('academy::lang.duration') . ':') !!}
                    {!! Form::number('duration', null, ['class' => 'form-control', 'placeholder' => __('academy::lang.duration')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('capacity', __('academy::lang.capacity') . ':') !!}
                    {!! Form::number('capacity', null, ['class' => 'form-control', 'placeholder' => __('academy::lang.capacity')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    {!! Form::checkbox('is_fixed_session', 1, null, ['id' => 'is_fixed_session']) !!}
                    {!! Form::label('is_fixed_session', __('academy::lang.is_fixed_session')) !!}
                    <small class="form-text text-muted">@lang('academy::lang.fixed_session_help')</small>
                </div>
            </div>
        </div>

        <div id="fixed_session_fields" style="display: none;">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        {!! Form::label('session_duration_minutes', __('academy::lang.session_duration_minutes') . ':') !!}
                        {!! Form::number('session_duration_minutes', null, ['class' => 'form-control', 'min' => 1, 'placeholder' => __('academy::lang.session_duration_minutes')]) !!}
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        {!! Form::label('sessions_per_week', __('academy::lang.sessions_per_week') . ':') !!}
                        {!! Form::number('sessions_per_week', null, ['class' => 'form-control', 'min' => 1, 'placeholder' => __('academy::lang.sessions_per_week')]) !!}
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        {!! Form::label('total_sessions', __('academy::lang.total_sessions') . ':') !!}
                        {!! Form::number('total_sessions', null, ['class' => 'form-control', 'min' => 1, 'placeholder' => __('academy::lang.total_sessions')]) !!}
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    {!! Form::label('short_description', __('academy::lang.description') . ':') !!}
                    {!! Form::textarea('short_description', null, ['class' => 'form-control', 'rows' => 3, 'placeholder' => __('academy::lang.description')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    {!! Form::label('long_description', __('academy::lang.long_description') . ':') !!}
                    {!! Form::textarea('long_description', null, ['class' => 'form-control', 'rows' => 5, 'placeholder' => __('academy::lang.long_description')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <button type="submit" class="tw-dw-btn tw-dw-btn-primary">
                    @lang('messages.save')
                </button>
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyCourseController::class, 'index']) }}" class="tw-dw-btn tw-dw-btn-outline tw-dw-btn-secondary">
                    @lang('messages.cancel')
                </a>
            </div>
        </div>
        {!! Form::close() !!}
    @endcomponent
</section>
@endsection

@section('javascript')
<script type="text/javascript">
    $(document).ready(function() {
        // Toggle fixed session fields
        $('#is_fixed_session').change(function() {
            if ($(this).is(':checked')) {
                $('#fixed_session_fields').show();
            } else {
                $('#fixed_session_fields').hide();
                // Clear the fields when unchecked
                $('#fixed_session_fields input').val('');
            }
        });
    });
</script>
@endsection