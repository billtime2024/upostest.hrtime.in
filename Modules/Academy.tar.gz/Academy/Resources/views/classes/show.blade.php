@extends('academy::layouts.master')
@section('title', __('academy::lang.classes'))
@section('content')
<section class="content-header">
    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
        @lang('academy::lang.classes')
    </h1>
</section>

<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('title')
            @lang('messages.view')
        @endslot

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.name'):</strong>
                    <p>{{ $class->name }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.course'):</strong>
                    <p>{{ $class->course ? $class->course->name : __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.instructor'):</strong>
                    <p>{{ $class->instructor ? $class->instructor->username : __('academy::lang.na') }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('business.business_location'):</strong>
                    <p>{{ $class->location ? $class->location->name : __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.start_date'):</strong>
                    <p>{{ $class->start_date ? $class->start_date->format('Y-m-d') : __('academy::lang.na') }}</p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.end_date'):</strong>
                    <p>{{ $class->end_date ? $class->end_date->format('Y-m-d') : __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.schedule'):</strong>
                    <p>
                        @if($class->schedule && is_array($class->schedule))
                            @if(isset($class->schedule['description']))
                                {{ $class->schedule['description'] }}
                            @endif
                            @if(isset($class->schedule['selected_days']) && !empty($class->schedule['selected_days']))
                                <br><strong>@lang('academy::lang.select_days'):</strong>
                                @foreach($class->schedule['selected_days'] as $day)
                                    {{ __('academy::lang.' . $day) }}
                                    @if(!$loop->last), @endif
                                @endforeach
                            @endif
                        @elseif($class->schedule)
                            {{ $class->schedule }}
                        @else
                            {{ __('academy::lang.na') }}
                        @endif
                    </p>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>@lang('academy::lang.capacity'):</strong>
                    <p>{{ $class->capacity ?: __('academy::lang.na') }}</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <strong>@lang('academy::lang.description'):</strong>
                    <p>{!! $class->description ?: __('academy::lang.na') !!}</p>
                </div>
            </div>
        </div>

        @if($class->enrollments && $class->enrollments->count() > 0)
        <div class="row">
            <div class="col-md-12">
                <h4>@lang('academy::lang.enrollments')</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>@lang('academy::lang.student')</th>
                            <th>@lang('lang_v1.created_at')</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($class->enrollments as $enrollment)
                        <tr>
                            <td>{{ $enrollment->student ? $enrollment->student->contact->name : __('academy::lang.na') }}</td>
                            <td>{{ $enrollment->created_at ? $enrollment->created_at->format('Y-m-d') : __('academy::lang.na') }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        @endif

        @if($class->sessions && $class->sessions->count() > 0)
        <div class="row">
            <div class="col-md-12">
                <h4>@lang('academy::lang.sessions')</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>@lang('lang_v1.date')</th>
                            <th>@lang('lang_v1.time')</th>
                            <th>@lang('lang_v1.created_at')</th>
                            <th>@lang('messages.actions')</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($class->sessions as $session)
                        <tr>
                            <td>{{ $session->date ? $session->date->format('Y-m-d') : __('academy::lang.na') }}</td>
                            <td>{{ $session->start_time }} - {{ $session->end_time }}</td>
                            <td>{{ $session->created_at ? $session->created_at->format('Y-m-d') : __('academy::lang.na') }}</td>
                            <td>
                                <button class="btn btn-success btn-sm bulk-mark-present" data-session-id="{{ $session->id }}" data-present="1">
                                    @lang('academy::lang.mark_all_present')
                                </button>
                                <button class="btn btn-danger btn-sm bulk-mark-absent" data-session-id="{{ $session->id }}" data-present="0">
                                    @lang('academy::lang.mark_all_absent')
                                </button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        @endif

        <div class="row">
            <div class="col-md-12">
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'edit'], ['class' => $class->id]) }}" class="tw-dw-btn tw-dw-btn-primary">
                    @lang('messages.edit')
                </a>
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'index']) }}" class="tw-dw-btn tw-dw-btn-outline tw-dw-btn-secondary">
                    @lang('messages.back')
                </a>
            </div>
        </div>
    @endcomponent
</section>

@section('javascript')
<script>
$(document).ready(function() {
    $('.bulk-mark-present, .bulk-mark-absent').on('click', function() {
        var sessionId = $(this).data('session-id');
        var present = $(this).data('present');

        if (confirm('Are you sure you want to mark all students as ' + (present ? 'present' : 'absent') + ' for this session?')) {
            $.ajax({
                url: '{{ route("academy.attendances.bulk_mark") }}',
                method: 'POST',
                data: {
                    session_id: sessionId,
                    present: present,
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.msg);
                    } else {
                        toastr.error(response.msg);
                    }
                },
                error: function() {
                    toastr.error('{{ __("messages.something_went_wrong") }}');
                }
            });
        }
    });
});
</script>
@endsection