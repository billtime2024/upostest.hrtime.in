@extends('academy::layouts.master')
@section('title', __('academy::lang.classes'))
@section('content')
<section class="content-header">
    <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black">
        @lang('academy::lang.classes')
    </h1>
</section>

<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('title')
            @lang('messages.edit')
        @endslot

        {!! Form::open(['url' => action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'update'], ['class' => $class->id]), 'method' => 'put', 'id' => 'class_form']) !!}
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('name', __('academy::lang.name') . ':*') !!}
                    {!! Form::text('name', old('name', $class->name), ['class' => 'form-control', 'required', 'placeholder' => __('academy::lang.name')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('course_id', __('academy::lang.course') . ':*') !!}
                    {!! Form::select('course_id', $courses, old('course_id', $class->course_id), ['class' => 'form-control select2', 'required', 'placeholder' => __('messages.please_select')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('instructor_id', __('academy::lang.instructor') . ':') !!}
                    {!! Form::select('instructor_id', $instructors ?? [], old('instructor_id', $class->instructor_id), ['class' => 'form-control select2', 'placeholder' => __('messages.please_select')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('location_id', __('business.business_location') . ':') !!}
                    {!! Form::select('location_id', $locations ?? [], old('location_id', $class->location_id), ['class' => 'form-control select2', 'placeholder' => __('messages.please_select')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('start_date', __('academy::lang.start_date') . ':*') !!}
                    {!! Form::text('start_date', old('start_date', $class->start_date ? $class->start_date->format('Y-m-d') : null), ['class' => 'form-control datepicker', 'required', 'placeholder' => __('academy::lang.start_date')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('end_date', __('academy::lang.end_date') . ':*') !!}
                    {!! Form::text('end_date', old('end_date', $class->end_date ? $class->end_date->format('Y-m-d') : null), ['class' => 'form-control datepicker', 'required', 'placeholder' => __('academy::lang.end_date')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('schedule', __('academy::lang.schedule') . ':') !!}
                    {!! Form::textarea('schedule', old('schedule', is_array($class->schedule) ? json_encode($class->schedule) : $class->schedule), ['class' => 'form-control', 'rows' => 3, 'placeholder' => __('academy::lang.schedule')]) !!}
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    {!! Form::label('capacity', __('academy::lang.capacity') . ':*') !!}
                    {!! Form::number('capacity', old('capacity', $class->capacity), ['class' => 'form-control', 'required', 'min' => 1, 'placeholder' => __('academy::lang.capacity')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    {!! Form::label('selected_days', __('academy::lang.select_days') . ':') !!}
                    <div class="row">
                        @php
                            $selectedDays = old('selected_days', is_array($class->schedule) && isset($class->schedule['selected_days']) ? $class->schedule['selected_days'] : []);
                        @endphp
                        @foreach(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as $day)
                            <div class="col-md-3">
                                {!! Form::checkbox('selected_days[]', $day, in_array($day, $selectedDays), ['id' => 'day_' . $day]) !!}
                                {!! Form::label('day_' . $day, __('academy::lang.' . $day)) !!}
                            </div>
                        @endforeach
                    </div>
                    <small class="form-text text-muted">@lang('academy::lang.select_days_help')</small>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    {!! Form::label('description', __('academy::lang.description') . ':') !!}
                    {!! Form::textarea('description', old('description', $class->description), ['class' => 'form-control', 'rows' => 4, 'placeholder' => __('academy::lang.description')]) !!}
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    {!! Form::checkbox('auto_generate_sessions', 1, old('auto_generate_sessions', $class->auto_generate_sessions), ['id' => 'auto_generate_sessions']) !!}
                    {!! Form::label('auto_generate_sessions', __('academy::lang.auto_generate_sessions')) !!}
                    <small class="form-text text-muted">@lang('academy::lang.session_generation_help')</small>
                </div>
            </div>
        </div>

        <div id="session_generation_fields" style="{{ $class->auto_generate_sessions ? '' : 'display: none;' }}">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        {!! Form::label('default_session_start_time', __('academy::lang.default_session_start_time') . ':') !!}
                        {!! Form::time('default_session_start_time', old('default_session_start_time', $class->default_session_start_time ? $class->default_session_start_time->format('H:i') : null), ['class' => 'form-control', 'placeholder' => __('academy::lang.default_session_start_time')]) !!}
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        {!! Form::label('default_session_end_time', __('academy::lang.default_session_end_time') . ':') !!}
                        {!! Form::time('default_session_end_time', old('default_session_end_time', $class->default_session_end_time ? $class->default_session_end_time->format('H:i') : null), ['class' => 'form-control', 'placeholder' => __('academy::lang.default_session_end_time')]) !!}
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <button type="submit" class="tw-dw-btn tw-dw-btn-primary">
                    @lang('messages.save')
                </button>
                <a href="{{ action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'index']) }}" class="tw-dw-btn tw-dw-btn-outline tw-dw-btn-secondary">
                    @lang('messages.cancel')
                </a>
            </div>
        </div>
        {!! Form::close() !!}
    @endcomponent
</section>
@endsection

@section('javascript')
<script type="text/javascript">
    $(document).ready(function() {
        $('.select2').select2();

        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true
        });

        // Toggle session generation fields
        $('#auto_generate_sessions').change(function() {
            if ($(this).is(':checked')) {
                $('#session_generation_fields').show();
            } else {
                $('#session_generation_fields').hide();
                // Clear the fields when unchecked
                $('#session_generation_fields input').val('');
            }
        });
    });
</script>
@endsection