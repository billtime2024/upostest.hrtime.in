@extends('academy::layouts.master')
@section('title', __('academy::lang.classes'))
@section('content')
    <section class="content-header">
        <h1 class="tw-text-xl md:tw-text-3xl tw-font-bold tw-text-black"> @lang('academy::lang.classes')
        </h1>
        <p><i class="fa fa-info-circle"></i> @lang('academy::lang.classes_help_text', ['default' => 'Manage your academy classes here.']) </p>
    </section>

    <!-- Main content -->
    <section class="content">
        @component('components.filters', ['title' => __('report.filters')])
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('course_id', __('academy::lang.course') . ':') !!}
                    {!! Form::select('course_id', $courses ?? [], null, [
                        'class' => 'form-control select2',
                        'style' => 'width:100%',
                        'placeholder' => __('lang_v1.all'),
                    ]) !!}
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('instructor_id', __('academy::lang.instructor') . ':') !!}
                    {!! Form::select('instructor_id', $instructors ?? [], null, [
                        'class' => 'form-control select2',
                        'style' => 'width:100%',
                        'placeholder' => __('lang_v1.all'),
                    ]) !!}
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('location_id', __('business.business_location') . ':') !!}
                    {!! Form::select('location_id', $locations ?? [], null, [
                        'class' => 'form-control select2',
                        'style' => 'width:100%',
                        'placeholder' => __('lang_v1.all'),
                    ]) !!}
                </div>
            </div>
        @endcomponent
        @component('components.widget')
            <div class="box-tools tw-flex tw-justify-end tw-gap-2.5 tw-mb-4">
                @can('academy.manage_classes')
                        <a class="tw-dw-btn tw-bg-gradient-to-r tw-from-indigo-600 tw-to-blue-500 tw-font-bold tw-text-white tw-border-none tw-rounded-full pull-right"
                            href="{{ action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'create']) }}">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                class="icon icon-tabler icons-tabler-outline icon-tabler-plus">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M12 5l0 14" />
                                <path d="M5 12l14 0" />
                            </svg> @lang('messages.add')
                        </a>
                @endcan
            </div>
            <table class="table table-bordered table-striped" id="classes_table">
                <thead>
                    <tr>
                        <th>
                            @lang('academy::lang.name')
                        </th>
                        <th>
                            @lang('academy::lang.course')
                        </th>
                        <th>
                            @lang('academy::lang.instructor')
                        </th>
                        <th>
                            @lang('business.business_location')
                        </th>
                        <th>
                            @lang('academy::lang.start_date')
                        </th>
                        <th>
                            @lang('academy::lang.end_date')
                        </th>
                        <th>
                            @lang('academy::lang.capacity')
                        </th>
                        <th>
                            @lang('lang_v1.created_at')
                        </th>
                        <th>
                            @lang('messages.action')
                        </th>
                    </tr>
                </thead>
            </table>
        @endcomponent
    </section>
@endsection

@section('javascript')
    <script type="text/javascript">
        $(document).ready(function() {
            classes_table = $('#classes_table').DataTable({
                processing: true,
                serverSide: true,

                ajax: {
                    url: "{{ action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'index']) }}",
                    "data": function(d) {
                        d.course_id = $('#course_id').val();
                        d.instructor_id = $('#instructor_id').val();
                        d.location_id = $('#location_id').val();
                    },
                },
                aaSorting: [
                    [7, 'desc']
                ],
                columns: [{
                        data: 'name',
                        name: 'academy_classes.name'
                    },
                    {
                        data: 'course_name',
                        name: 'course.title',
                    },
                    {
                        data: 'instructor_name',
                        name: 'instructor.username',
                        "searchable": false
                    },
                    {
                        data: 'location_name',
                        name: 'location.name',
                        "searchable": false
                    },
                    {
                        data: 'start_date',
                        name: 'academy_classes.start_date'
                    },
                    {
                        data: 'end_date',
                        name: 'academy_classes.end_date'
                    },
                    {
                        data: 'capacity',
                        name: 'academy_classes.capacity'
                    },
                    {
                        data: 'created_at',
                        name: 'academy_classes.created_at'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        sorting: false,
                    }
                ],
            });

            $(document).on('change', '#course_id, #instructor_id, #location_id', function() {
                classes_table.ajax.reload();
            });

        });
    </script>
@endsection