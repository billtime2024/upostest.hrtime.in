@extends('academy::layouts.master')

@section('title', __('academy::lang.academy_dashboard'))

@section('content')
<section class="content no-print">
    <div class="row">
        <div class="col-md-4">
            <!-- Statistics Cards -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">@lang('academy::lang.statistics')</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="description-block border-right">
                                <span class="description-header">{{ $total_courses ?? 0 }}</span>
                                <span class="description-text">@lang('academy::lang.total_courses')</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="description-block">
                                <span class="description-header">{{ $total_classes ?? 0 }}</span>
                                <span class="description-text">@lang('academy::lang.total_classes')</span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="description-block border-right">
                                <span class="description-header">{{ $total_students ?? 0 }}</span>
                                <span class="description-text">@lang('academy::lang.total_students')</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="description-block">
                                <span class="description-header">{{ $total_enrollments ?? 0 }}</span>
                                <span class="description-text">@lang('academy::lang.total_enrollments')</span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="description-block">
                                <span class="description-header">{{ $total_revenue ?? 0 }}</span>
                                <span class="description-text">@lang('academy::lang.total_revenue')</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <!-- Recent Enrollments -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">@lang('academy::lang.recent_enrollments')</h3>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        @forelse($recent_enrollments ?? [] as $enrollment)
                            <li class="list-group-item">{{ $enrollment->student_name ?? __('academy::lang.student') }} enrolled in {{ $enrollment->course_name ?? __('academy::lang.course') }}</li>
                        @empty
                            <li class="list-group-item">@lang('academy::lang.no_recent_enrollments')</li>
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <!-- Charts -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">@lang('academy::lang.enrollment_trends')</h3>
                </div>
                <div class="card-body">
                    <canvas id="enrollmentTrendsChart"></canvas>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">@lang('academy::lang.recent_enrollments_chart')</h3>
                </div>
                <div class="card-body">
                    <canvas id="recentEnrollmentsChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection

@section('javascript')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    var ctx1 = document.getElementById('enrollmentTrendsChart').getContext('2d');
    var enrollmentTrendsChart = new Chart(ctx1, {
        type: 'line',
        data: {
            labels: {!! json_encode($enrollment_trends_labels ?? []) !!},
            datasets: [{
                label: '{{ __("academy::lang.enrollments_label") }}',
                data: {!! json_encode($enrollment_trends_data ?? []) !!},
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
            }]
        }
    });

    var ctx2 = document.getElementById('recentEnrollmentsChart').getContext('2d');
    var recentEnrollmentsChart = new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: {!! json_encode($recent_enrollments_labels ?? []) !!},
            datasets: [{
                label: '{{ __("academy::lang.recent_enrollments") }}',
                data: {!! json_encode($recent_enrollments_data ?? []) !!},
                backgroundColor: 'rgba(153, 102, 255, 0.2)',
                borderColor: 'rgba(153, 102, 255, 1)',
            }]
        }
    });
</script>
@endsection