<?php

namespace Modules\Academy\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Academy\Entities\AcademyClass;
use Modules\Academy\Entities\AcademyCourse;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\DB;
use App\Utils\ModuleUtil;

class AcademyClassController extends Controller
{

    protected $moduleUtil;

    public function __construct(ModuleUtil $moduleUtil)
    {
        $this->moduleUtil = $moduleUtil;
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_classes')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $classes = AcademyClass::where('academy_classes.business_id', $business_id)
                ->with(['course', 'instructor', 'location'])
                ->leftJoin('academy_courses', 'academy_classes.course_id', '=', 'academy_courses.id')
                ->leftJoin('users', 'academy_classes.instructor_id', '=', 'users.id')
                ->leftJoin('business_locations', 'academy_classes.location_id', '=', 'business_locations.id');

            // Apply filters
            if (!empty(request()->course_id)) {
                $classes->where('academy_classes.course_id', request()->course_id);
            }
            if (!empty(request()->instructor_id)) {
                $classes->where('academy_classes.instructor_id', request()->instructor_id);
            }
            if (!empty(request()->location_id)) {
                $classes->where('academy_classes.location_id', request()->location_id);
            }

            return Datatables::of($classes)
                ->editColumn('created_at', '{{@format_datetime($created_at)}}')
                ->addColumn('course_name', function ($row) {
                    return $row->course ? $row->course->name : '';
                })
                ->addColumn('instructor_name', function ($row) {
                    return $row->instructor ? $row->instructor->username : '';
                })
                ->addColumn('location_name', function ($row) {
                    return $row->location ? $row->location->name : '';
                })
                ->addColumn('action', function ($row) {
                    $html = '<a type="button" class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-primary" href="' . action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'edit'], ['class' => $row->id]) . '">'
                        . __('academy::lang.edit_class') . '</a>';
                    $html .= ' <a type="button" class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-info" href="' . action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'show'], ['class' => $row->id]) . '">'
                        . __('messages.view') . '</a>';
                    $html .= ' <a href="' . action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'destroy'], [$row->id]) . '"
                    class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-error delete_class_confirmation">' . __('messages.delete') . '</a>';

                    return $html;
                })
                ->editColumn('description', '{!! $description !!}')
                ->rawColumns(['created_at', 'action', 'description'])
                ->make(true);
        }

        $courses = \Modules\Academy\Entities\AcademyCourse::where('business_id', $business_id)->pluck('title', 'id');
        $instructors = \App\User::where('business_id', $business_id)->pluck('username', 'id');
        $locations = \App\BusinessLocation::where('business_id', $business_id)->pluck('name', 'id');

        return view('academy::classes.index', compact('courses', 'instructors', 'locations'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_classes')) {
            abort(403, 'Unauthorized action.');
        }

        $courses = AcademyCourse::where('business_id', $business_id)->pluck('title', 'id');
        $instructors = \App\User::where('business_id', $business_id)->pluck('username', 'id');
        $locations = \App\BusinessLocation::where('business_id', $business_id)->pluck('name', 'id');

        return view('academy::classes.create', compact('courses', 'instructors', 'locations'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_classes')) {
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'course_id' => 'required|exists:academy_courses,id',
            'instructor_id' => 'nullable|exists:users,id',
            'location_id' => 'nullable|exists:business_locations,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'schedule' => 'nullable|string',
            'selected_days' => 'nullable|array',
            'selected_days.*' => 'in:monday,tuesday,wednesday,thursday,friday,saturday,sunday',
            'capacity' => 'required|integer|min:1',
            'description' => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            $input = $request->except(['_token', 'selected_days']);
            $input['created_by'] = auth()->user()->id;
            $input['business_id'] = $business_id;

            // Handle schedule as array
            $schedule = [];
            if (!empty($input['schedule'])) {
                $schedule['description'] = $input['schedule'];
            }
            if ($request->has('selected_days') && !empty($request->selected_days)) {
                $schedule['selected_days'] = $request->selected_days;
            }
            $input['schedule'] = $schedule;

            $class = AcademyClass::create($input);

            // Auto-generate sessions if enabled
            if ($class->auto_generate_sessions && $class->course->is_fixed_session) {
                $this->generateSessionsForClass($class);
            }

            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('academy::lang.class_created_successfully'),
            ];

            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_classes')) {
            abort(403, 'Unauthorized action.');
        }

        $class = AcademyClass::where('business_id', $business_id)->with(['course', 'sessions', 'enrollments.student'])->findOrFail($id);

        return view('academy::classes.show', compact('class'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_classes')) {
            abort(403, 'Unauthorized action.');
        }

        $class = AcademyClass::where('business_id', $business_id)->findOrFail($id);
        $courses = AcademyCourse::where('business_id', $business_id)->pluck('title', 'id');
        $instructors = \App\User::where('business_id', $business_id)->pluck('username', 'id');
        $locations = \App\BusinessLocation::where('business_id', $business_id)->pluck('name', 'id');

        return view('academy::classes.edit', compact('class', 'courses', 'instructors', 'locations'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_classes')) {
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'course_id' => 'required|exists:academy_courses,id',
            'instructor_id' => 'nullable|exists:users,id',
            'location_id' => 'nullable|exists:business_locations,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'schedule' => 'nullable|string',
            'selected_days' => 'nullable|array',
            'selected_days.*' => 'in:monday,tuesday,wednesday,thursday,friday,saturday,sunday',
            'capacity' => 'required|integer|min:1',
            'description' => 'nullable|string',
        ]);

        $class = AcademyClass::where('business_id', $business_id)->findOrFail($id);
        DB::beginTransaction();
        try {
            $input = $request->except(['_token', 'selected_days']);

            // Handle schedule as array
            $schedule = $class->schedule ?? [];
            if (!empty($input['schedule'])) {
                $schedule['description'] = $input['schedule'];
            } elseif (isset($schedule['description'])) {
                // Keep existing if not updated
            } else {
                unset($schedule['description']);
            }
            if ($request->has('selected_days')) {
                if (!empty($request->selected_days)) {
                    $schedule['selected_days'] = $request->selected_days;
                } else {
                    unset($schedule['selected_days']);
                }
            }
            $input['schedule'] = $schedule;

            $class->update($input);

            // Auto-generate sessions if enabled and course is fixed session
            if ($class->auto_generate_sessions && $class->course->is_fixed_session) {
                // Delete existing sessions first
                $class->sessions()->delete();
                $this->generateSessionsForClass($class);
            }

            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('academy::lang.class_updated_successfully'),
            ];

            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_classes')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $class = AcademyClass::find($id);
            $class->delete();

            $output = ['success' => 1, 'msg' => __('lang_v1.success')];
            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyClassController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Generate sessions for a class based on course and class settings.
     */
    private function generateSessionsForClass(AcademyClass $class)
    {
        $course = $class->course;

        // Only generate if course is fixed session and has required settings
        if (!$course->is_fixed_session ||
            !$course->session_duration_minutes ||
            !$course->sessions_per_week ||
            !$course->total_sessions) {
            return;
        }

        // Get class settings
        $startDate = $class->start_date;
        $endDate = $class->end_date;
        $selectedDays = $class->schedule['selected_days'] ?? [];
        $defaultStartTime = $class->default_session_start_time;
        $defaultEndTime = $class->default_session_end_time;

        if (empty($selectedDays) || !$defaultStartTime || !$defaultEndTime) {
            return;
        }

        $sessionsCreated = 0;
        $currentDate = $startDate->copy();

        // Map day names to Carbon day numbers (0 = Sunday, 1 = Monday, etc.)
        $dayMap = [
            'sunday' => 0,
            'monday' => 1,
            'tuesday' => 2,
            'wednesday' => 3,
            'thursday' => 4,
            'friday' => 5,
            'saturday' => 6,
        ];

        $selectedDayNumbers = array_map(function($day) use ($dayMap) {
            return $dayMap[strtolower($day)] ?? null;
        }, $selectedDays);

        $selectedDayNumbers = array_filter($selectedDayNumbers);

        // Generate sessions
        while ($currentDate <= $endDate && $sessionsCreated < $course->total_sessions) {
            $dayOfWeek = $currentDate->dayOfWeek;

            if (in_array($dayOfWeek, $selectedDayNumbers)) {
                // Create session
                \Modules\Academy\Entities\AcademySession::create([
                    'class_id' => $class->id,
                    'session_date' => $currentDate->format('Y-m-d'),
                    'start_time' => $defaultStartTime->format('H:i:s'),
                    'end_time' => $defaultEndTime->format('H:i:s'),
                    'topic' => 'Session ' . ($sessionsCreated + 1),
                    'room_id' => $class->location_id,
                    'business_id' => $class->business_id,
                    'created_by' => auth()->user()->id,
                ]);

                $sessionsCreated++;
            }

            $currentDate->addDay();
        }
    }
}