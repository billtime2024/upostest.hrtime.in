<?php

namespace Modules\Academy\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Academy\Entities\AcademySession;
use Modules\Academy\Entities\AcademyClass;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\DB;
use App\Utils\ModuleUtil;

class AcademySessionController extends Controller
{

    protected $moduleUtil;

    public function __construct(ModuleUtil $moduleUtil)
    {
        $this->moduleUtil = $moduleUtil;
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.manage_sessions')){
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $sessions = AcademySession::where('business_id', $business_id);
            return Datatables::of($sessions)
                ->editColumn('created_at', '{{@format_datetime($created_at)}}')
                ->addColumn('action', function ($row) {
                    $html = '<a type="button" class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline  tw-dw-btn-primary " href="' . action([\Modules\Academy\Http\Controllers\AcademySessionController::class, 'edit'], ['session' => $row->id]) . '">'
                        . __('academy::lang.edit_session') . '</a>';
                    $html .= ' <a href="' . action([\Modules\Academy\Http\Controllers\AcademySessionController::class, 'destroy'], [$row->id]) . '"
                    class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline  tw-dw-btn-error delete_session_confirmation">' . __('messages.delete') . '</a>';

                return $html;
                })
                ->rawColumns(['created_at', 'action'])
                ->make(true);
        }
        return view('academy::sessions.index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.manage_sessions')){
            abort(403, 'Unauthorized action.');
        }

        $classes = AcademyClass::where('business_id', $business_id)
                            ->select(['name', 'id'])->get();

        return view('academy::sessions.create', compact('classes'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.manage_sessions')){
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'academy_class_id' => 'required|exists:academy_classes,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'start_time' => 'required',
            'end_time' => 'required',
        ]);

        DB::beginTransaction();
        try {
            $input =  $request->except(['_token']);
            $input['created_by'] = auth()->user()->id;
            $input['business_id'] = $business_id;

            $session = AcademySession::create($input);
            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('academy::lang.session_created_successfully'),
            ];

            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademySessionController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.manage_sessions')){
            abort(403, 'Unauthorized action.');
        }

        $session = AcademySession::where('business_id', $business_id)->with('attendances')->findOrFail($id);

        return view('academy::sessions.show', compact('session'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.manage_sessions')){
            abort(403, 'Unauthorized action.');
        }

        $session = AcademySession::where('business_id', $business_id)->findOrFail($id);

        $classes = AcademyClass::where('business_id', $business_id)
                            ->select(['name', 'id'])->get();

        return view('academy::sessions.edit', compact('session', 'classes'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.manage_sessions')){
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'academy_class_id' => 'required|exists:academy_classes,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'start_time' => 'required',
            'end_time' => 'required',
        ]);

        $session = AcademySession::where('business_id', $business_id)->findOrFail($id);
        DB::beginTransaction();
        try {
            $input =  $request->except(['_token']);

            $session->update($input);
            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('academy::lang.session_updated_successfully'),
            ];

            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademySessionController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.manage_sessions')){
            abort(403, 'Unauthorized action.');
        }

        try {
            $session = AcademySession::find($id);
            $session->delete();

            $output = ['success' => 1, 'msg' => __('lang_v1.success')];
            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademySessionController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }
}