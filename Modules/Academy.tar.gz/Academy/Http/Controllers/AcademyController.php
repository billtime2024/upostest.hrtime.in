<?php

namespace Modules\Academy\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use App\Transaction;
use Illuminate\Support\Carbon;
use Modules\Academy\Entities\AcademyCourse;
use Modules\Academy\Entities\AcademyClass;
use Modules\Academy\Entities\AcademyStudent;
use Modules\Academy\Entities\AcademyEnrollment;
use App\Charts\CommonChart;
use App\Utils\ModuleUtil;
use Modules\Academy\Entities\AcademyTransactionClass;


class AcademyController extends Controller
{
    protected $moduleUtil;
    protected $businessUtil;

    public function __construct(ModuleUtil $moduleUtil, \App\Utils\BusinessUtil $businessUtil)
    {
        $this->moduleUtil = $moduleUtil;
        $this->businessUtil = $businessUtil;
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        $total_courses = AcademyCourse::where('business_id', $business_id)->count();
        $total_classes = AcademyClass::where('business_id', $business_id)->count();
        $total_students = AcademyStudent::where('business_id', $business_id)->count();
        $total_enrollments = AcademyEnrollment::where('business_id', $business_id)->count();

        $revenue = Transaction::where('business_id', $business_id)
            ->where('type', 'academy_enrollment')
            ->sum('final_total');

        // Latest enrollments
        $latest_enrollments = AcademyTransactionClass::where('transactions.business_id', $business_id)
            ->with(['contact'])
            ->where('transactions.type', 'academy_enrollment')
            ->orderBy('transactions.created_at', 'desc')
            ->take(5)
            ->get();

        // Chart for enrollment trends upcoming 6 days
        $labels = [];
        $dates = [];
        for ($i = 0; $i < 7; $i++) {
            $date = \Carbon\Carbon::now()->addDays($i)->format('Y-m-d');
            $dates[] = $date;
            $labels[] = date('j M Y', strtotime($date));
            $total_enrollment_on_date = $this->get_enrollment_count($date);
            $all_enrollment_values[] = !empty($total_enrollment_on_date) ? (float) $total_enrollment_on_date : 0;
        }
        $enrollment_chart = new CommonChart;
        $enrollment_chart->labels($labels)->options($this->__chartOptions(__('academy::lang.enrollments')));
        $enrollment_chart->dataset(__('academy::lang.enrollments'), 'line', $all_enrollment_values);

        // Chart for enrollment past 6 days
        $labels = [];
        $dates = [];
        $all_enrollment_values = [];
        for ($i = 7; $i >= 1; $i--) {
            $date = \Carbon\Carbon::now()->subDays($i)->format('Y-m-d');
            $dates[] = $date;
            $labels[] = date('j M Y', strtotime($date));
            $total_enrollment_on_date = $this->get_enrollment_count($date);
            $all_enrollment_values[] = !empty($total_enrollment_on_date) ? (float) $total_enrollment_on_date : 0;
        }
        $past_enrollment_chart = new CommonChart;
        $past_enrollment_chart->labels($labels)->options($this->__chartOptions(__('academy::lang.enrollments')));
        $past_enrollment_chart->dataset(__('academy::lang.enrollments'), 'line', $all_enrollment_values);

        return view('academy::dashboard.index', compact('enrollment_chart', 'past_enrollment_chart', 'total_courses', 'total_classes', 'total_students', 'total_enrollments', 'revenue', 'latest_enrollments'));
    }

    /**
     * Show the calendar view for classes and sessions.
     * @param Request $request
     * @return Renderable
     */
    public function calendar(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        $courses = AcademyCourse::where('business_id', $business_id)->pluck('title', 'id')->toArray();

        $classes = AcademyClass::leftjoin('academy_courses as course', 'course.id', '=', 'academy_classes.course_id')
            ->where('course.business_id', $business_id)
            ->select('academy_classes.*', 'course.title as course_name', 'course.id as course_id');

        if ($request->course_id) {
            $classes = $classes->where('course.id', $request->course_id);
        }

        $classes = $classes->get();

        $start_date = now();

        if ($request->day_next) {
            $start_date = now()->startOfWeek()->addDays($request->day_next);
        }

        if ($request->week_next) {
            $start_date = $start_date->addWeeks($request->week_next);
        }

        if ($request->date) {
            $start_date = Carbon::parse($request->date);
        }

        $date_html = '';
        $html = '';
        $class = '';
        $header_date = $start_date->copy();

        for ($i = 0; $i <= 6; $i++) {
            $header_date = $start_date->copy();

            if ($request->day_next) {
                $current_date = $header_date->clone();
                $current_date->addDays($i);

                if ($current_date->format('Y-m-d') == now()->format('Y-m-d')) {
                    $class = 'bg-success';
                }
                $date_html .= '<th style="width: 100px;" class="text-center ' . $class . '">
                    ' . $current_date->format('d') . ' <br>
                    ' . $current_date->format("l") . '
                    </th>';
            } else {
                if ($header_date->startOfWeek()->addDays($i)->format('Y-m-d') == now()->format('Y-m-d')) {
                    $class = 'bg-success';
                }
                $date_html .= '<th style="width: 100px;" class="text-center ' . $class . '">
                    ' . $header_date->startOfWeek()->addDays($i)->format('d') . ' <br>
                    ' . $header_date->startOfWeek()->addDays($i)->format("l") . '
                    </th>';
            }
            $class = '';
        }

        foreach ($classes as $class_item) {
            $html .= '<tr><th class="text-center">' . $class_item->name . ' <br> <small>' . $class_item->course_name . '</small></th>';

            $ref_no = '';
            $size = 100;
            $temp_size = 100;

            for ($j = 0; $j <= 6; $j++) {
                $row_date = $start_date->copy();
                $days = $j;

                if ($request->day_next) {
                    $date = $row_date->addDays($days)->format('Y-m-d');
                } else {
                    $date = $row_date->startOfWeek()->addDays($days)->format('Y-m-d');
                }

                $is_session = $this->is_session($date, $class_item->id);
                if ($is_session) {
                    if ($ref_no == $is_session->ref_no) {
                        $size = $size + 100;
                        $html .= '<td></td>';
                    } else {
                        $html .= '<td><div class="academy-session-outer tooltip-demo">
                            <a href="' . action([\Modules\Academy\Http\Controllers\AcademyController::class, 'index']) . '" class="academy-session" data-toggle="tooltip" data-html="true" data-placement="bottom" title="" style=" left: 0%;" data-original-title="' . $is_session->email . '<br>Phone: ' . $is_session->mobile . '<br/>Students: ' . $is_session->students . '<br/>ID: ' . $is_session->ref_no . '">
                                <div class="academy-session-inner bg-confirmed" style="width: 100%;"' . $is_session->ref_no . '><strong>' . $is_session->name . '</strong>
                                <br><button class="btn btn-success btn-xs bulk-mark-present" data-session-id="' . $is_session->id . '" data-present="1" title="' . __('academy::lang.mark_all_present') . '"><i class="fa fa-check"></i></button>
                                <button class="btn btn-danger btn-xs bulk-mark-absent" data-session-id="' . $is_session->id . '" data-present="0" title="' . __('academy::lang.mark_all_absent') . '"><i class="fa fa-times"></i></button>
                                </div>
                            </a>
                            </div></td>';
                        $ref_no = $is_session->ref_no;
                        $size = 100;
                        $temp_size = 100;
                    }
                } else {
                    $html .= '<td class="text-center add_session">
                        <div class="add_session_div"><a title="Add Session" href="#"><i class="fa fa-fw fa-plus"></i></a></div>
                        </td>';
                }
                if ($is_session) {
                    $ref_no = $is_session->ref_no;
                } else {
                    $ref_no = '';
                }

                if ($size >= 100) {
                    $html = str_replace('style="width: ' . $temp_size . '%;"' . $ref_no . '', 'style="width: ' . $size . '%;"' . $ref_no . '', $html);
                    $temp_size = $size;
                }
            }
            $html .= '</tr>';
        }

        return view('academy::calendar.index', compact('courses', 'classes', 'start_date', 'html', 'date_html'));
    }

    private function __chartOptions($title)
    {
        return [
            'yAxis' => [
                'title' => [
                    'text' => $title,
                ],
            ],
            'legend' => [
                'align' => 'right',
                'verticalAlign' => 'top',
                'floating' => true,
                'layout' => 'vertical',
                'padding' => 20,
            ],
        ];
    }

    public function get_enrollment_count($date)
    {
        $business_id = request()->session()->get('user.business_id');

        return Transaction::where('transactions.type', 'academy_enrollment')
            ->where('transactions.business_id', $business_id)
            ->whereDate('transactions.created_at', '=', $date)
            ->count();
    }

    public function is_session($date, $class_id)
    {
        // Assuming AcademySession has similar structure
        $sessions = \Modules\Academy\Entities\AcademySession::where('academy_sessions.class_id', $class_id)
            ->whereDate('academy_sessions.session_date', '=', $date)
            ->leftJoin('academy_enrollments', 'academy_enrollments.class_id', '=', 'academy_sessions.class_id')
            ->leftJoin('academy_students', 'academy_students.id', '=', 'academy_enrollments.student_id')
            ->leftJoin('transactions', 'transactions.id', '=', 'academy_enrollments.transaction_id')
            ->where('transactions.status', 'confirmed')
            ->leftJoin('contacts AS c', 'c.id', '=', 'academy_students.contact_id')
            ->select('transactions.ref_no', 'c.name', 'c.email', 'c.mobile', DB::raw('COUNT(academy_enrollments.id) as students'))
            ->groupBy('academy_sessions.id')
            ->first();

        return $sessions;
    }
}