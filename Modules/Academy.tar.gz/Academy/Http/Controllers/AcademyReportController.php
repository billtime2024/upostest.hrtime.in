<?php

namespace Modules\Academy\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Transaction;
use App\Utils\Util;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Utils\ModuleUtil;
use Datatables;

class AcademyReportController extends Controller
{
    protected $moduleUtil;

    public function __construct(ModuleUtil $moduleUtil)
    {
        $this->moduleUtil = $moduleUtil;
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');
        
        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if ($request->date_to && $request->date_from) {
            // Placeholder for date-based reports, similar to Hms
            // For now, return view
            return view('academy::report.index');
        }
        return view('academy::report.index');
    }

    public function enrollment_report(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if ($request->ajax()) {
            // Placeholder query for enrollment reports
            $query = Transaction::where('business_id', $business_id)
                ->where('type', 'academy_enrollment')
                ->select('id', 'ref_no', 'transaction_date', 'final_total');

            if (!empty($request->date_from)) {
                $query->whereDate('transaction_date', '>=', $request->date_from);
            }
            if (!empty($request->date_to)) {
                $query->whereDate('transaction_date', '<=', $request->date_to);
            }

            return Datatables::of($query)
                ->editColumn('transaction_date', '{{@format_date($transaction_date)}}')
                ->make(true);
        }
    }

    public function attendance_report(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if ($request->ajax()) {
            // Placeholder query for attendance reports
            $query = Transaction::where('business_id', $business_id)
                ->where('type', 'academy_attendance')
                ->select('id', 'ref_no', 'transaction_date', 'final_total');

            if (!empty($request->date_from)) {
                $query->whereDate('transaction_date', '>=', $request->date_from);
            }
            if (!empty($request->date_to)) {
                $query->whereDate('transaction_date', '<=', $request->date_to);
            }

            return Datatables::of($query)
                ->editColumn('transaction_date', '{{@format_date($transaction_date)}}')
                ->make(true);
        }
    }

    public function revenue_report(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if ($request->ajax()) {
            // Placeholder query for revenue reports
            $query = Transaction::where('business_id', $business_id)
                ->where('type', 'academy_revenue')
                ->select('id', 'ref_no', 'transaction_date', 'final_total');

            if (!empty($request->date_from)) {
                $query->whereDate('transaction_date', '>=', $request->date_from);
            }
            if (!empty($request->date_to)) {
                $query->whereDate('transaction_date', '<=', $request->date_to);
            }

            return Datatables::of($query)
                ->editColumn('transaction_date', '{{@format_date($transaction_date)}}')
                ->make(true);
        }
    }
}