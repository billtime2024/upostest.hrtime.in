<?php

namespace Modules\Academy\Http\Controllers;

use App\Business;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Utils\ModuleUtil;

class AcademySettingController extends Controller
{
    protected $moduleUtil;

    public function __construct(ModuleUtil $moduleUtil)
    {
        $this->moduleUtil = $moduleUtil;
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $business_id = request()->session()->get('user.business_id');
        
        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        $busines = Business::findOrFail($business_id);

        return view('academy::settings.index', compact('busines'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');
        
        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }
        
        try {
            $setting = $request->post('academy');
            $business_id = session()->get('user.business_id');
    
            $busines = Business::findOrFail($business_id);

            $academy_settings = json_decode($busines->academy_settings, true);

            $academy_settings['prefix'] = $request->prefix;
            $busines->academy_settings = json_encode($academy_settings);
   
            $busines->update();
    
            $output = [
                'success' => 1,
                'msg' => __('lang_v1.success'),
            ];
    
            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademySettingController::class, 'index'])
                ->with('status', $output);
                
        } catch (\Exception $e) {
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }

    }
}