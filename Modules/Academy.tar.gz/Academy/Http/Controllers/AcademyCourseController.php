<?php

namespace Modules\Academy\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Academy\Entities\AcademyCourse;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\DB;
use App\Utils\ModuleUtil;

class AcademyCourseController extends Controller
{

    protected $moduleUtil;

    public function __construct(ModuleUtil $moduleUtil)
    {
        $this->moduleUtil = $moduleUtil;
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_courses')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $courses = AcademyCourse::where('business_id', $business_id);
            return Datatables::of($courses)
                ->editColumn('created_at', function ($row) {
                    return \Carbon\Carbon::parse($row->created_at)->format('Y-m-d H:i:s');
                })
                ->addColumn('action', function ($row) {
                    $html = '<a type="button" class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-primary" href="' . action([\Modules\Academy\Http\Controllers\AcademyCourseController::class, 'edit'], ['course' => $row->id]) . '">'
                        . __('academy::lang.edit_course') . '</a>';
                    $html .= ' <a href="' . action([\Modules\Academy\Http\Controllers\AcademyCourseController::class, 'destroy'], [$row->id]) . '"
                    class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-error delete_course_confirmation">' . __('messages.delete') . '</a>';

                    return $html;
                })
                ->editColumn('short_description', function ($row) {
                    return $row->short_description;
                })
                ->rawColumns(['action', 'short_description'])
                ->make(true);
        }
        return view('academy::courses.index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_courses')) {
            abort(403, 'Unauthorized action.');
        }

        return view('academy::courses.create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_courses')) {
            abort(403, 'Unauthorized action.');
        }

        DB::beginTransaction();
        try {
            $input = $request->except(['_token']);
            $input['created_by'] = auth()->user()->id;
            $input['business_id'] = $business_id;

            // Generate code if needed
            if (!isset($input['code']) || empty($input['code'])) {
                $input['code'] = $this->generateCourseCode($business_id);
            }

            $course = AcademyCourse::create($input);

            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('academy::lang.course_created_successfully'),
            ];

            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyCourseController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_courses')) {
            abort(403, 'Unauthorized action.');
        }

        $course = AcademyCourse::where('business_id', $business_id)->findOrFail($id);

        return view('academy::courses.show', compact('course'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_courses')) {
            abort(403, 'Unauthorized action.');
        }

        $course = AcademyCourse::where('business_id', $business_id)->findOrFail($id);

        return view('academy::courses.edit', compact('course'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_courses')) {
            abort(403, 'Unauthorized action.');
        }

        $course = AcademyCourse::where('business_id', $business_id)->findOrFail($id);
        DB::beginTransaction();
        try {
            $input = $request->except(['_token']);

            $course->update($input);

            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('academy::lang.course_updated_successfully'),
            ];

            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyCourseController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_courses')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $course = AcademyCourse::find($id);
            $course->delete();

            $output = ['success' => 1, 'msg' => __('lang_v1.success')];
            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyCourseController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Generate a unique course code.
     */
    private function generateCourseCode($business_id)
    {
        $count = AcademyCourse::where('business_id', $business_id)->count() + 1;
        return 'COURSE-' . str_pad($count, 4, '0', STR_PAD_LEFT);
    }
}