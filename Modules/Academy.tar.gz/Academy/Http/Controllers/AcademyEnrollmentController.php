<?php

namespace Modules\Academy\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Contact;
use App\Transaction;
use App\Business;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;
use App\Utils\NotificationUtil;
use App\NotificationTemplate;
use Notification;
use App\Utils\ContactUtil;
use App\Utils\TransactionUtil;
use App\CustomerGroup;
use App\Utils\ModuleUtil;
use App\Utils\BusinessUtil;
use App\Account;
use App\Notifications\CustomerNotification;
use Modules\Academy\Entities\AcademyEnrollment;
use Modules\Academy\Entities\AcademyStudent;
use Modules\Academy\Entities\AcademyClass;
use Modules\Academy\Entities\AcademyCourse;

class AcademyEnrollmentController extends Controller
{
    protected $moduleUtil;
    protected $transactionUtil;
    protected $notificationUtil;
    protected $contactUtil;
    protected $businessUtil;
    protected $dummyPaymentLine;

    public function __construct(
        ModuleUtil $moduleUtil, TransactionUtil $transactionUtil, NotificationUtil $notificationUtil, ContactUtil $contactUtil, BusinessUtil $businessUtil
    ) {
        $this->moduleUtil = $moduleUtil;
        $this->transactionUtil = $transactionUtil;
        $this->notificationUtil = $notificationUtil;
        $this->contactUtil = $contactUtil;
        $this->businessUtil = $businessUtil;

        $this->dummyPaymentLine = ['method' => 'cash', 'amount' => 0, 'note' => '', 'card_transaction_number' => '', 'card_number' => '', 'card_type' => '', 'card_holder_name' => '', 'card_month' => '', 'card_year' => '', 'card_security' => '', 'cheque_number' => '', 'bank_account_number' => '',
        'is_return' => 0, 'transaction_no' => '', ];
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $payment_types = $this->transactionUtil->payment_types(null, true, $business_id);

            $enrollment = AcademyEnrollment::where('academy_enrollments.business_id', $business_id)
                        ->leftjoin('transactions as t', 'academy_enrollments.transaction_id', '=', 't.id')
                        ->leftjoin('academy_students as s', 'academy_enrollments.student_id', '=', 's.id')
                        ->leftjoin('contacts as c', 's.contact_id', '=', 'c.id')
                        ->leftjoin('academy_classes as cl', 'academy_enrollments.class_id', '=', 'cl.id')
                        ->leftjoin('academy_courses as course', 'cl.course_id', '=', 'course.id')
                        ->select('academy_enrollments.*', 'c.name as student_name', 'course.title as course_name', 't.final_total as total_amount', 't.payment_status', DB::raw('(SELECT SUM(IF(TP.is_return = 1,-1*TP.amount,TP.amount)) FROM transaction_payments AS TP WHERE TP.transaction_id=t.id) as total_paid'));

            // filter with student
            if($request->student_id){
                $enrollment = $enrollment->where('s.id',$request->student_id);
            }
            // filter with course
            if($request->course_id){
                $enrollment = $enrollment->where('course.id',$request->course_id);
            }
            // filter with status
            if($request->status){
                $enrollment = $enrollment->where('academy_enrollments.status',$request->status);
            }

            // filter with payment_status
            if (! empty(request()->input('payment_status')) && request()->input('payment_status') != 'overdue') {
                $enrollment->where('t.payment_status', request()->input('payment_status'));
            } elseif (request()->input('payment_status') == 'overdue') {
                $enrollment->whereIn('t.payment_status', ['due', 'partial'])
                    ->whereNotNull('t.pay_term_number')
                    ->whereNotNull('t.pay_term_type')
                    ->whereRaw("IF(t.pay_term_type='days', DATE_ADD(t.transaction_date, INTERVAL t.pay_term_number DAY) < CURDATE(), DATE_ADD(t.transaction_date, INTERVAL t.pay_term_number MONTH) < CURDATE())");
            }

            return Datatables::of($enrollment)

                ->editColumn('created_at', '{{@format_datetime($created_at)}}')

                ->addColumn('action', function ($row) {
                    $html = '';
                    if(auth()->user()->can( 'academy.edit_enrollment')){
                        $html = '<a type="button" class="tw-dw-btn tw-dw-btn-primary tw-dw-btn-outline tw-dw-btn-xs btn-modal-extra " href="' . action([\Modules\Academy\Http\Controllers\AcademyEnrollmentController::class, 'edit'], ['enrollment' => $row->id]) . '">'
                        . __('academy::lang.edit_enrollment') . '</a>';
                    }

                    $html .= '<a type="button" class="tw-dw-btn tw-dw-btn-success tw-dw-btn-outline tw-dw-btn-xs btn-modal-extra" href="' . action([\Modules\Academy\Http\Controllers\AcademyEnrollmentController::class, 'show'], ['enrollment' => $row->id]) . '" style="margin:4px">'
                    . __('academy::lang.view') . '</a>';
                    return $html;
                })
                ->editColumn(
                    'payment_status',
                    function ($row) {
                        $payment_status = Transaction::getPaymentStatus($row);

                        return (string) view('sell.partials.payment_status', ['payment_status' => $payment_status, 'id' => $row->id]);
                    }
                )
                ->editColumn('enrollment_date', '{{@format_datetime($enrollment_date)}}')

                ->editColumn('status', function($row){
                    if($row->status == 'enrolled'){

                        return '<h6 class="badge bg-green">'.__('academy::lang.enrolled').'</h6>';

                    }elseif($row->status == 'waitlisted'){
                        return '<h6 class="badge bg-yellow">'.__('academy::lang.waitlisted').'</h6>';
                    }elseif($row->status == 'cancelled'){
                        return '<h6 class="badge bg-red">'.__('academy::lang.cancelled').'</h6>';
                    }elseif($row->status == 'completed'){
                        return '<h6 class="badge bg-blue">'.__('academy::lang.completed').'</h6>';
                    }
                })
                ->editColumn(
                    'total_amount',
                    '<span class="final-total" data-orig-value="{{$total_amount}}">@format_currency($total_amount)</span>'
                )
                ->editColumn(
                    'total_paid',
                    '<span class="total-paid" data-orig-value="{{$total_paid}}">@format_currency($total_paid)</span>'
                )
                ->addColumn('total_due', function ($row) {
                    $total_due = $row->total_amount - $row->total_paid;
                    $total_due_html = '<span class="payment_due" data-orig-value="'.$total_due.'">'.$this->transactionUtil->num_f($total_due, true).'</span>';

                    return $total_due_html;
                })
                ->rawColumns(['created_at', 'action', 'enrollment_date', 'status', 'payment_status', 'total_amount', 'total_paid', 'total_due'])
                ->make(true);
        }

        $students = AcademyStudent::where('academy_students.business_id', $business_id)
            ->leftjoin('contacts as c', 'academy_students.contact_id', '=', 'c.id')
            ->pluck('c.name', 'academy_students.id')
            ->toArray();
        $courses = AcademyCourse::where('business_id', $business_id)->pluck('title', 'id')->toArray();
        $status = [
            'enrolled' => __('academy::lang.enrolled'),
            'waitlisted' => __('academy::lang.waitlisted'),
            'cancelled' => __('academy::lang.cancelled'),
            'completed' => __('academy::lang.completed'),
        ];
        return view('academy::enrollments.index', compact('students', 'courses', 'status'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.add_enrollment')){
            abort(403, 'Unauthorized action.');
        }

        $status = [
            'enrolled' => __('academy::lang.enrolled'),
            'waitlisted' => __('academy::lang.waitlisted'),
            'cancelled' => __('academy::lang.cancelled'),
        ];

        $students = AcademyStudent::where('academy_students.business_id', $business_id)
            ->leftjoin('contacts as c', 'academy_students.contact_id', '=', 'c.id')
            ->pluck('c.name', 'academy_students.id')
            ->toArray();

        $courses = AcademyCourse::where('business_id', $business_id)->pluck('title', 'id')->toArray();
        $classes = []; // Will be loaded via AJAX

        $walk_in_customer = $this->contactUtil->getWalkInCustomer($business_id);

        $types = [];
        if (auth()->user()->can('supplier.create')) {
            $types['supplier'] = __('report.supplier');
        }
        if (auth()->user()->can('customer.create')) {
            $types['customer'] = __('report.customer');
        }
        if (auth()->user()->can('supplier.create') && auth()->user()->can('customer.create')) {
            $types['both'] = __('lang_v1.both_supplier_customer');
        }

        $customer_groups = CustomerGroup::forDropdown($business_id);

        $payment_line = $this->dummyPaymentLine;

        $change_return = $this->dummyPaymentLine;

        $payment_types = $this->transactionUtil->payment_types(null, true, $business_id);

        $business_details = $this->businessUtil->getDetails($business_id);

        $pos_settings = empty($business_details->pos_settings) ? $this->businessUtil->defaultPosSettings() : json_decode($business_details->pos_settings, true);

        $accounts = [];
        if ($this->moduleUtil->isModuleEnabled('account')) {
            $accounts = Account::forDropdown($business_id, true, false, true);
        }

        return view('academy::enrollments.create', compact('status', 'students', 'courses', 'classes', 'walk_in_customer', 'types', 'customer_groups', 'payment_line', 'payment_types', 'pos_settings', 'change_return', 'accounts'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.add_enrollment')){
            abort(403, 'Unauthorized action.');
        }

        DB::beginTransaction();
        try{
            $business_id = request()->session()->get('user.business_id');

            // Validate request
            $request->validate([
                'student_id' => 'required|exists:academy_students,id,business_id,' . $business_id,
                'course_id' => 'required|exists:academy_courses,id,business_id,' . $business_id,
                'class_id' => 'required|exists:academy_classes,id,business_id,' . $business_id,
                'enrollment_date' => 'required|date',
                'status' => 'required|in:enrolled,waitlisted,cancelled',
                'enrollment_fee' => 'required|numeric|min:0',
                'course_fee' => 'required|numeric|min:0',
                'discount' => 'nullable|numeric|min:0',
            ]);

            // Validate class belongs to selected course
            $class = AcademyClass::where('id', $request->class_id)
                ->where('course_id', $request->course_id)
                ->where('business_id', $business_id)
                ->first();
            if (!$class) {
                throw new \Exception(__('academy::lang.class_not_belongs_to_course'));
            }

            // Check class capacity
            $current_enrollments = AcademyEnrollment::where('class_id', $request->class_id)->count();
            if ($class->capacity && $current_enrollments >= $class->capacity) {
                throw new \Exception(__('academy::lang.class_capacity_exceeded'));
            }

            // Check if class is within valid dates
            $today = now()->toDateString();
            if ($class->end_date && $class->end_date < $today) {
                throw new \Exception(__('academy::lang.class_ended'));
            }

            $busines = Business::findOrFail($business_id);

            $prefix = json_decode($busines->academy_settings)->prefix ?? null;

            $ref_no = null;

            $ref_count = $this->transactionUtil->setAndGetReferenceCount("academy_enrollment", $business_id);
            //Generate reference number
            $ref_no = $this->transactionUtil->generateReferenceNumber('academy_enrollment', $ref_count, $business_id, $prefix);

            // Get student and contact
            $student = AcademyStudent::findOrFail($request->student_id);
            $contact_id = $student->contact_id;

            // Set default fees from course if not provided
            if ((!$request->enrollment_fee || $request->enrollment_fee == 0) && (!$request->course_fee || $request->course_fee == 0)) {
                $course = AcademyCourse::findOrFail($request->course_id);
                $request->merge(['enrollment_fee' => $course->default_fee ?? 0, 'course_fee' => 0]);
            }

            // store in transaction
            $transaction = new Transaction();
            $transaction->business_id = $business_id;
            $transaction->type = 'academy_enrollment';
            $transaction->status = 'final';
            $transaction->contact_id = $contact_id;
            $transaction->created_by = auth()->user()->id;
            $transaction->ref_no = $ref_no;
            $transaction->total_before_tax = $request->total_enrollment_amount ?? 0;
            $transaction->final_total = $request->total_enrollment_amount ?? 0;
            $transaction->transaction_date = now();
            $transaction->save();

            // Create enrollment
            $enrollment = new AcademyEnrollment();
            $enrollment->class_id = $request->class_id;
            $enrollment->student_id = $request->student_id;
            $enrollment->enrollment_date = $request->enrollment_date;
            $enrollment->status = $request->status;
            $enrollment->enrollment_fee = $request->enrollment_fee;
            $enrollment->course_fee = $request->course_fee;
            $enrollment->discount = $request->discount;
            $enrollment->transaction_id = $transaction->id;
            $enrollment->business_id = $business_id;
            $enrollment->created_by = auth()->user()->id;
            $enrollment->save();

            //Add change return
            $input = $request->except('_token');
            //Add change return
            $change_return = $this->dummyPaymentLine;
            if (! empty($input['payment']['change_return'])) {
                $change_return = $input['payment']['change_return'];
                unset($input['payment']['change_return']);
            }

            $change_return['amount'] = $input['change_return'] ?? 0;
            $change_return['is_return'] = 1;

            $input['payment'][] = $change_return;

            if (! empty($input['payment'])) {
                $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment']);
            }

            $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);

            // send notification to customer
            $template = NotificationTemplate::where('template_for', 'academy_new_enrollment')->where('business_id', $business_id)->first();

            if($template && $template->auto_send){

                $data = [
                    'email_body' => $template->email_body,
                    'subject' => $template->subject,
                ];

                $customer = Contact::findOrFail($transaction->contact_id);

                $tag_replaced_data = $this->notificationUtil->replaceAcademyEnrollmentTags($data, $transaction, $customer);

                $orig_data = [
                    'email_body' => $tag_replaced_data['email_body'],
                    'subject' => $tag_replaced_data['subject'],
                    'cc' => $template->cc,
                    'bcc' => $template->bcc,
                ];

                Notification::route('mail', $customer->email)->notify(new CustomerNotification($orig_data));
            }

            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('lang_v1.success'),
            ];

            return redirect()->action(
                [\Modules\Academy\Http\Controllers\AcademyEnrollmentController::class, 'index'])
                    ->with('status', $output);

        }
        catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $business_id = request()->session()->get('user.business_id');

        $transaction = Transaction::where('transactions.business_id', $business_id)
                        ->with(['contact'])
                        ->where('transactions.type', 'academy_enrollment')
                        ->findOrFail($id);
                        
        return view('academy::enrollments.show', compact('transaction'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.edit_enrollment')){
            abort(403, 'Unauthorized action.');
        }

        $transaction = Transaction::where('transactions.business_id', $business_id)
                        ->findOrFail($id);

        $enrollment = AcademyEnrollment::where('transaction_id', $id)->first();

        $status = [
            'enrolled' => __('academy::lang.enrolled'),
            'waitlisted' => __('academy::lang.waitlisted'),
            'cancelled' => __('academy::lang.cancelled'),
        ];

        $students = AcademyStudent::where('academy_students.business_id', $business_id)
            ->leftjoin('contacts as c', 'academy_students.contact_id', '=', 'c.id')
            ->pluck('c.name', 'academy_students.id')
            ->toArray();

        $courses = AcademyCourse::where('business_id', $business_id)->pluck('title', 'id')->toArray();
        $classes = []; // Will be loaded via AJAX
        $selected_course = $enrollment ? AcademyClass::find($enrollment->class_id)->course_id ?? null : null;

        $customer_due = $this->transactionUtil->getContactDue($transaction->contact_id, $transaction->business_id);

        $types = [];
        if (auth()->user()->can('supplier.create')) {
            $types['supplier'] = __('report.supplier');
        }
        if (auth()->user()->can('customer.create')) {
            $types['customer'] = __('report.customer');
        }
        if (auth()->user()->can('supplier.create') && auth()->user()->can('customer.create')) {
            $types['both'] = __('lang_v1.both_supplier_customer');
        }

        $customer_groups = CustomerGroup::forDropdown($business_id);

        $customer_due = $customer_due != 0 ? $this->transactionUtil->num_f($customer_due, true) : '';

        $payment_types = $this->transactionUtil->payment_types(null, true, $business_id);

        $business_details = $this->businessUtil->getDetails($business_id);

        $pos_settings = empty($business_details->pos_settings) ? $this->businessUtil->defaultPosSettings() : json_decode($business_details->pos_settings, true);

        $payment_lines = $this->transactionUtil->getPaymentDetails($id);
        //If no payment lines found then add dummy payment line.
        if (empty($payment_lines)) {
            $payment_lines[] = $this->dummyPaymentLine;
        }

        $change_return = $this->dummyPaymentLine;


        $accounts = [];
        if ($this->moduleUtil->isModuleEnabled('account')) {
            $accounts = Account::forDropdown($business_id, true, false, true);
        }

        return view('academy::enrollments.edit', compact('status', 'students', 'courses', 'classes', 'selected_course', 'transaction', 'enrollment', 'types', 'customer_groups', 'customer_due', 'payment_types', 'pos_settings', 'payment_lines', 'change_return', 'accounts'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if(!auth()->user()->can( 'academy.edit_enrollment')){
            abort(403, 'Unauthorized action.');
        }

        DB::beginTransaction();
        try{
            // Validate request
            $request->validate([
                'student_id' => 'required|exists:academy_students,id,business_id,' . $business_id,
                'course_id' => 'required|exists:academy_courses,id,business_id,' . $business_id,
                'class_id' => 'required|exists:academy_classes,id,business_id,' . $business_id,
                'enrollment_date' => 'required|date',
                'status' => 'required|in:enrolled,waitlisted,cancelled',
                'enrollment_fee' => 'required|numeric|min:0',
                'course_fee' => 'required|numeric|min:0',
                'discount' => 'nullable|numeric|min:0',
            ]);

            // Validate class belongs to selected course
            $class = AcademyClass::where('id', $request->class_id)
                ->where('course_id', $request->course_id)
                ->where('business_id', $business_id)
                ->first();
            if (!$class) {
                throw new \Exception(__('academy::lang.class_not_belongs_to_course'));
            }

            // Check class capacity (exclude current enrollment if class hasn't changed)
            $current_enrollment = AcademyEnrollment::where('transaction_id', $id)->first();
            $exclude_current = ($current_enrollment && $current_enrollment->class_id == $request->class_id) ? 1 : 0;
            $current_enrollments = AcademyEnrollment::where('class_id', $request->class_id)->count() - $exclude_current;
            if ($class->capacity && $current_enrollments >= $class->capacity) {
                throw new \Exception(__('academy::lang.class_capacity_exceeded'));
            }

            // Check if class is within valid dates
            $today = now()->toDateString();
            if ($class->end_date && $class->end_date < $today) {
                throw new \Exception(__('academy::lang.class_ended'));
            }

            // store in transaction
            $transaction = Transaction::findOrFail($id);

            // Get student and contact
            $student = AcademyStudent::findOrFail($request->student_id);
            $contact_id = $student->contact_id;

            // Set default fees from course if not provided
            if ((!$request->enrollment_fee || $request->enrollment_fee == 0) && (!$request->course_fee || $request->course_fee == 0)) {
                $course = AcademyCourse::findOrFail($request->course_id);
                $request->merge(['enrollment_fee' => $course->default_fee ?? 0, 'course_fee' => 0]);
            }

            $transaction->status = 'final';
            $transaction->contact_id = $contact_id;

            $transaction->total_before_tax = $request->total_enrollment_amount ?? 0;

            $transaction->final_total = $request->total_enrollment_amount ?? 0;

            $transaction->update();

            // Update or create enrollment
            $enrollment = AcademyEnrollment::where('transaction_id', $id)->first();
            if (!$enrollment) {
                $enrollment = new AcademyEnrollment();
                $enrollment->transaction_id = $transaction->id;
                $enrollment->business_id = $business_id;
                $enrollment->created_by = auth()->user()->id;
            }
            $enrollment->class_id = $request->class_id;
            $enrollment->student_id = $request->student_id;
            $enrollment->enrollment_date = $request->enrollment_date;
            $enrollment->status = $request->status;
            $enrollment->enrollment_fee = $request->enrollment_fee;
            $enrollment->course_fee = $request->course_fee;
            $enrollment->discount = $request->discount;
            $enrollment->save();

            //Add change return
            $input = $request->except('_token');
            $change_return = $this->dummyPaymentLine;
            if (! empty($input['payment']['change_return'])) {
                $change_return = $input['payment']['change_return'];
                unset($input['payment']['change_return']);
            }

            //Add change return
            $change_return['amount'] = $input['change_return'] ?? 0;
            $change_return['is_return'] = 1;
            if (! empty($input['change_return_id'])) {
                $change_return['payment_id'] = $input['change_return_id'];
            }
            $input['payment'][] = $change_return;

            if (! empty($input['payment'])) {
                $this->transactionUtil->createOrUpdatePaymentLines($transaction, $input['payment']);
            }

            $this->transactionUtil->updatePaymentStatus($transaction->id, $transaction->final_total);

            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('lang_v1.success'),
            ];

            return redirect()->action(
                [\Modules\Academy\Http\Controllers\AcademyEnrollmentController::class, 'index'])->with('status', $output);;

        }
        catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }

    }

    /**
     * Get classes by course for AJAX
     * @param int $course_id
     * @return \Illuminate\Http\JsonResponse
     */
    public function getClassesByCourse($course_id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        $classes = AcademyClass::where('business_id', $business_id)
            ->where('course_id', $course_id)
            ->where('end_date', '>=', now())
            ->pluck('name', 'id')
            ->toArray();

        return response()->json($classes);
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}