<?php

namespace Modules\Academy\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Academy\Entities\AcademyAttendance;
use Modules\Academy\Entities\AcademySession;
use Modules\Academy\Entities\AcademyEnrollment;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\DB;
use App\Utils\ModuleUtil;

class AcademyAttendanceController extends Controller
{

    protected $moduleUtil;

    public function __construct(ModuleUtil $moduleUtil)
    {
        $this->moduleUtil = $moduleUtil;
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_attendance')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $attendances = AcademyAttendance::where('business_id', $business_id)
                ->with(['session', 'enrollment.student.contact'])
                ->select('*');

            return Datatables::of($attendances)
                ->editColumn('created_at', '{{@format_datetime($created_at)}}')
                ->addColumn('action', function ($row) {
                    $html = '<a type="button" class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-primary" href="' . action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'edit'], ['attendance' => $row->id]) . '">'
                        . __('messages.edit') . '</a>';
                    $html .= ' <a href="' . action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'destroy'], [$row->id]) . '"
                    class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-error delete_attendance_confirmation">' . __('messages.delete') . '</a>';

                    return $html;
                })
                ->editColumn('present', function ($row) {
                    return $row->present ? __('academy::lang.present') : __('academy::lang.absent');
                })
                ->editColumn('check_in_time', '{{@format_datetime($check_in_time)}}')
                ->rawColumns(['created_at', 'action', 'present', 'check_in_time'])
                ->make(true);
        }

        return view('academy::attendances.index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_attendance')) {
            abort(403, 'Unauthorized action.');
        }

        $sessions = AcademySession::where('business_id', $business_id)
            ->select('id', DB::raw("CONCAT(IFNULL(topic, ''), IF(topic IS NOT NULL AND topic != '', ' - ', ''), DATE_FORMAT(session_date, '%Y-%m-%d'), ' ', TIME_FORMAT(start_time, '%H:%i'), ' - ', TIME_FORMAT(end_time, '%H:%i')) as display_name"))
            ->pluck('display_name', 'id');
        $enrollments = AcademyEnrollment::where('business_id', $business_id)->with('student.contact')->get()->pluck('student.contact.name', 'id');

        return view('academy::attendances.create', compact('sessions', 'enrollments'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_attendance')) {
            abort(403, 'Unauthorized action.');
        }

        DB::beginTransaction();
        try {
            $input = $request->only(['session_id', 'enrollment_id', 'present', 'check_in_time', 'remarks']);
            $input['business_id'] = $business_id;
            $input['created_by'] = auth()->user()->id;

            AcademyAttendance::create($input);

            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('lang_v1.success'),
            ];

            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_attendance')) {
            abort(403, 'Unauthorized action.');
        }

        $attendance = AcademyAttendance::where('business_id', $business_id)->with(['session', 'enrollment.student.contact'])->findOrFail($id);

        return view('academy::attendances.show', compact('attendance'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_attendance')) {
            abort(403, 'Unauthorized action.');
        }

        $attendance = AcademyAttendance::where('business_id', $business_id)->findOrFail($id);

        $sessions = AcademySession::where('business_id', $business_id)
            ->select('id', DB::raw("CONCAT(IFNULL(topic, ''), IF(topic IS NOT NULL AND topic != '', ' - ', ''), DATE_FORMAT(session_date, '%Y-%m-%d'), ' ', TIME_FORMAT(start_time, '%H:%i'), ' - ', TIME_FORMAT(end_time, '%H:%i')) as display_name"))
            ->pluck('display_name', 'id');
        $enrollments = AcademyEnrollment::where('business_id', $business_id)->with('student.contact')->get()->pluck('student.contact.name', 'id');

        return view('academy::attendances.edit', compact('attendance', 'sessions', 'enrollments'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_attendance')) {
            abort(403, 'Unauthorized action.');
        }

        $attendance = AcademyAttendance::where('business_id', $business_id)->findOrFail($id);

        DB::beginTransaction();
        try {
            $input = $request->only(['session_id', 'enrollment_id', 'present', 'check_in_time', 'remarks']);

            $attendance->update($input);

            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('lang_v1.success'),
            ];

            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_attendance')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $attendance = AcademyAttendance::where('business_id', $business_id)->findOrFail($id);
            $attendance->delete();

            $output = ['success' => 1, 'msg' => __('lang_v1.success')];
            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Bulk mark attendance for all enrolled students in a session.
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function bulkMarkAttendance(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_attendance')) {
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'session_id' => 'required|integer',
            'present' => 'required|boolean',
        ]);

        DB::beginTransaction();
        try {
            $session = AcademySession::where('business_id', $business_id)->findOrFail($request->session_id);
            $enrollments = AcademyEnrollment::where('business_id', $business_id)
                ->where('class_id', $session->class_id)
                ->get();

            foreach ($enrollments as $enrollment) {
                AcademyAttendance::updateOrCreate(
                    [
                        'session_id' => $request->session_id,
                        'enrollment_id' => $enrollment->id,
                        'business_id' => $business_id,
                    ],
                    [
                        'present' => $request->present,
                        'check_in_time' => $request->present ? now() : null,
                        'remarks' => null,
                        'created_by' => auth()->user()->id,
                    ]
                );
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'msg' => __('lang_v1.success'),
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            return response()->json([
                'success' => false,
                'msg' => __('messages.something_went_wrong'),
            ]);
        }
    }
}