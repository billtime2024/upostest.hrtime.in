<?php

namespace Modules\Academy\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Academy\Entities\AcademyStudent;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\DB;
use App\Utils\ModuleUtil;
use App\Utils\ContactUtil;
use App\Contact;

class AcademyStudentController extends Controller
{

    protected $moduleUtil;
    protected $contactUtil;

    public function __construct(ModuleUtil $moduleUtil, ContactUtil $contactUtil)
    {
        $this->moduleUtil = $moduleUtil;
        $this->contactUtil = $contactUtil;
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_students')) {
            abort(403, 'Unauthorized action.');
        }

        if (request()->ajax()) {
            $students = AcademyStudent::where('academy_students.business_id', $business_id)
                ->leftJoin('contacts', 'academy_students.contact_id', '=', 'contacts.id')
                ->select('academy_students.*')
                ->orderBy('academy_students.created_at', 'desc');
            return Datatables::of($students)
                ->editColumn('created_at', '{{@format_datetime($created_at)}}')
                ->addColumn('contact_name', function ($row) {
                    return $row->contact ? $row->contact->name : '';
                })
                ->addColumn('email', function ($row) {
                    return $row->contact ? $row->contact->email : '';
                })
                ->addColumn('phone', function ($row) {
                    return $row->contact ? $row->contact->mobile : '';
                })
                ->addColumn('action', function ($row) {
                    $html = '<a type="button" class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-primary" href="' . action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'edit'], ['student' => $row->id]) . '">'
                        . __('academy::lang.edit_student') . '</a>';
                    $html .= ' <a href="' . action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'destroy'], [$row->id]) . '"
                    class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-error delete_student_confirmation">' . __('messages.delete') . '</a>';
                    $html .= ' <a href="' . action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'show'], [$row->id]) . '"
                    class="tw-dw-btn tw-dw-btn-xs tw-dw-btn-outline tw-dw-btn-info">' . __('messages.view') . '</a>';

                    return $html;
                })
                ->rawColumns(['created_at', 'action'])
                ->make(true);
        }
        return view('academy::students.index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_students')) {
            abort(403, 'Unauthorized action.');
        }

        $contacts = Contact::where('business_id', $business_id)
                            ->whereIn('type', ['customer', 'both'])
                            ->select('name', 'id')
                            ->get();

        return view('academy::students.create', compact('contacts'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_students')) {
            abort(403, 'Unauthorized action.');
        }

        DB::beginTransaction();
        try {
            $input = $request->except(['_token']);
            $input['created_by'] = auth()->user()->id;
            $input['business_id'] = $business_id;

            // Generate admission_no if needed
            if (!isset($input['admission_no']) || empty($input['admission_no'])) {
                $input['admission_no'] = $this->generateAdmissionNo($business_id);
            }

            $student = AcademyStudent::create($input);

            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('academy::lang.student_created_successfully'),
            ];

            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_students')) {
            abort(403, 'Unauthorized action.');
        }

        $student = AcademyStudent::where('business_id', $business_id)->with(['contact', 'enrollments'])->findOrFail($id);

        return view('academy::students.show', compact('student'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_students')) {
            abort(403, 'Unauthorized action.');
        }

        $student = AcademyStudent::where('business_id', $business_id)->findOrFail($id);

        $contacts = Contact::where('business_id', $business_id)
                            ->whereIn('type', ['customer', 'both'])
                            ->select('name', 'id')
                            ->get();

        return view('academy::students.edit', compact('student', 'contacts'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_students')) {
            abort(403, 'Unauthorized action.');
        }

        $student = AcademyStudent::where('business_id', $business_id)->findOrFail($id);
        DB::beginTransaction();
        try {
            $input = $request->except(['_token']);

            $student->update($input);

            DB::commit();

            $output = [
                'success' => 1,
                'msg' => __('academy::lang.student_updated_successfully'),
            ];

            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $business_id = request()->session()->get('user.business_id');

        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'academy_module'))) {
            abort(403, 'Unauthorized action.');
        }

        if (!auth()->user()->can('academy.manage_students')) {
            abort(403, 'Unauthorized action.');
        }

        try {
            $student = AcademyStudent::where('business_id', $business_id)->find($id);
            $student->delete();

            $output = ['success' => 1, 'msg' => __('lang_v1.success')];
            return redirect()
                ->action([\Modules\Academy\Http\Controllers\AcademyStudentController::class, 'index'])
                ->with('status', $output);
        } catch (\Exception $e) {
            \Log::emergency('File:' . $e->getFile() . 'Line:' . $e->getLine() . 'Message:' . $e->getMessage());

            $output = [
                'success' => 0,
                'msg' => __('messages.something_went_wrong'),
            ];

            return back()->with('status', $output)->withInput();
        }
    }

    /**
     * Generate a unique admission number.
     */
    private function generateAdmissionNo($business_id)
    {
        $count = AcademyStudent::where('business_id', $business_id)->count() + 1;
        return 'ADM-' . str_pad($count, 4, '0', STR_PAD_LEFT);
    }
}