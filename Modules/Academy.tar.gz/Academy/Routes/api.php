<?php

use Illuminate\Http\Request;

Route::middleware('auth:api')->get('/academy', function (Request $request) {
    return $request->user();
});