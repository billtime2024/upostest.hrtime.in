<?php

use Illuminate\Http\Request;

Route::middleware('web', 'auth', 'language', 'AdminSidebarMenu')->group(function () {
    Route::resource('/courses', Modules\Academy\Http\Controllers\AcademyCourseController::class)->names('academy.courses');
    Route::resource('/classes', Modules\Academy\Http\Controllers\AcademyClassController::class)->names('academy.classes');
    Route::resource('/students', Modules\Academy\Http\Controllers\AcademyStudentController::class)->names('academy.students');
    Route::resource('/enrollments', Modules\Academy\Http\Controllers\AcademyEnrollmentController::class)->names('academy.enrollments');
    Route::get('/enrollments/get-classes/{course_id}', [Modules\Academy\Http\Controllers\AcademyEnrollmentController::class, 'getClassesByCourse'])->name('academy.enrollments.get_classes');
    Route::resource('/sessions', Modules\Academy\Http\Controllers\AcademySessionController::class)->names('academy.sessions');
    Route::resource('/attendances', Modules\Academy\Http\Controllers\AcademyAttendanceController::class)->names('academy.attendances');
    Route::post('/attendances/bulk-mark', [Modules\Academy\Http\Controllers\AcademyAttendanceController::class, 'bulkMarkAttendance'])->name('academy.attendances.bulk_mark');
    Route::resource('/extras', Modules\Academy\Http\Controllers\AcademyExtraController::class)->names('academy.extras');

    Route::get('/dashboard', [Modules\Academy\Http\Controllers\AcademyController::class, 'index']);
    Route::get('/calendar', [Modules\Academy\Http\Controllers\AcademyController::class, 'calendar'])->name('academy.calendar');
    Route::get('/reports', [Modules\Academy\Http\Controllers\AcademyReportController::class, 'index']);
    Route::get('/reports/enrollment', [Modules\Academy\Http\Controllers\AcademyReportController::class, 'enrollment_report']);
    Route::get('/reports/attendance', [Modules\Academy\Http\Controllers\AcademyReportController::class, 'attendance_report']);
    Route::get('/reports/revenue', [Modules\Academy\Http\Controllers\AcademyReportController::class, 'revenue_report']);
    Route::get('/settings', [Modules\Academy\Http\Controllers\AcademySettingController::class, 'index']);
    Route::post('/settings', [Modules\Academy\Http\Controllers\AcademySettingController::class, 'store']);
    Route::get('/install', [\Modules\Academy\Http\Controllers\InstallController::class, 'index']);
    Route::post('/install', [\Modules\Academy\Http\Controllers\InstallController::class, 'install']);
    Route::get('/install/uninstall', [\Modules\Academy\Http\Controllers\InstallController::class, 'uninstall']);
    Route::get('/install/update', [\Modules\Academy\Http\Controllers\InstallController::class, 'update']);
});