<?php

return [
    'name' => 'Academy',
    'module_version' => '1.0.0',
    'description' => 'Academy Management module for UltimatePOS, provides features for course management, student enrollments, attendance, and related features.',
    'author' => 'BillTime ERP',
    'version' => '1.0.0'
];