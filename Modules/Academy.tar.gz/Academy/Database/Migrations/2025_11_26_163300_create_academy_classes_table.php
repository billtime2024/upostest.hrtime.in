<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('academy_classes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->constrained('academy_courses');
            $table->string('name');
            $table->unsignedInteger('instructor_id')->nullable();
            $table->foreign('instructor_id')->references('id')->on('users');
            $table->unsignedInteger('location_id')->nullable();
            $table->foreign('location_id')->references('id')->on('business_locations');
            $table->date('start_date');
            $table->date('end_date');
            $table->json('schedule')->nullable();
            $table->integer('capacity')->nullable();
            $table->text('description')->nullable();
            $table->integer('business_id')->index();
            $table->foreignId('created_by');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('academy_classes');
    }
};