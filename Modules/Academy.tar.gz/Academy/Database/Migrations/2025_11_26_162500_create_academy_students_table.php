<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('academy_students', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('contact_id')->index();
            $table->string('admission_no')->nullable();
            $table->date('enrollment_date')->nullable();
            $table->json('extra_meta')->nullable();
            $table->integer('business_id')->index();
            $table->foreignId('created_by');
            $table->softDeletes();
            $table->timestamps();

            $table->unique(['business_id', 'admission_no']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('academy_students');
    }
};