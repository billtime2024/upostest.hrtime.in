<?php

namespace Modules\Academy\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Models\Permission;

class AcademyDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        // Seed permissions for Academy module
        $permissions = [
            'academy.access',
            'courses.view',
            'courses.create',
            'courses.update',
            'courses.delete',
            'students.view',
            'students.create',
            'students.update',
            'students.delete',
            'enrollments.view',
            'enrollments.create',
            'enrollments.update',
            'enrollments.delete',
            'calendar.view',
            'reports.view',
            'settings.access',
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate(['name' => $permission]);
        }
    }
}